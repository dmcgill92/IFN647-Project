﻿using Lucene.Net.Analysis;
using Lucene.Net.Documents;
using Lucene.Net.Index;
using Lucene.Net.QueryParsers;
using Lucene.Net.Search;
using Lucene.Net.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class Calculate
    {
        Lucene.Net.Store.Directory luceneIndexDirectory;
        Lucene.Net.Analysis.Analyzer analyzer;
        Lucene.Net.Index.IndexWriter writer;
        Lucene.Net.Search.IndexSearcher searcher;
        Lucene.Net.QueryParsers.QueryParser parser;


        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TEXT_FN = "Text";

        public Calculate()
        {
            luceneIndexDirectory = null;
            writer = null;
            analyzer = new Lucene.Net.Analysis.SimpleAnalyzer();
            parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TEXT_FN, analyzer);
        }

        public void CreateIndex(string indexPath)
        {
            luceneIndexDirectory = Lucene.Net.Store.FSDirectory.Open(indexPath);
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            writer = new Lucene.Net.Index.IndexWriter(luceneIndexDirectory, analyzer, true, mfl);
            //writer.SetSimilarity(newSimilarity); // Activity 9
        }


        /// <summary>
        /// Indexes a given string into the index
        /// </summary>
        /// <param name="text">The text to index</param>
        public void IndexText(string text)
        {

            Lucene.Net.Documents.Field field = new Field(TEXT_FN, text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Document doc = new Document();
            doc.Add(field);
            writer.AddDocument(doc);
        }


        /// <summary>
        /// Flushes the buffer and closes the index
        /// </summary>
        public void CleanUpIndexer()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }

        public void CleanUp()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }


        public void CreateSearcher()
        {
            searcher = new IndexSearcher(luceneIndexDirectory);
        }


        public List<string> SearchText(string querytext)
        {
            List<string> score_list = new List<string>();
            //System.Console.WriteLine("Searching for " + querytext);
            querytext = querytext.ToLower();
            Query query = parser.Parse(querytext);

            TopDocs results = searcher.Search(query, 100);
            //System.Console.WriteLine("Number of results is " + results.TotalHits);
            int rank = 0;
            foreach (ScoreDoc scoreDoc in results.ScoreDocs)
            {
                rank++;
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);
                string myFieldValue = doc.Get(TEXT_FN).ToString();
                //Console.WriteLine("Rank " + rank + " score " + scoreDoc.Score + " text " + myFieldValue); // Activity 8
                score_list.Add(scoreDoc.Score.ToString());
                //Console.WriteLine("Rank " + rank + " text " + myFieldValue);

                //Explanation e = searcher.Explain(query, scoreDoc.Doc); // Activity 8
                //System.Console.WriteLine(e.ToString());

            }
            return score_list;
        }

        public void CleanUpSearcher()
        {
            searcher.Dispose();
        }


        public List<string> return_score(string indexpath, string search_txt,List<string> mytextlist)
        {

            CreateIndex(indexpath);
            //System.Console.WriteLine("Adding Documents to Index");
            int docID = 0;
            foreach (string item in mytextlist)
            {
                IndexText(item);
                docID++;
            }
            //System.Console.WriteLine("All documents added.");
            CleanUpIndexer();
            CreateSearcher();

            List<string> score_list =SearchText(search_txt);

            return score_list;
        }


        public List<string> return_answer_query(string indexpath, string search_txt, List<string> mytextlist)
        {

            CreateIndex(indexpath);
            //System.Console.WriteLine("Adding Documents to Index");
            int docID = 0;
            foreach (string item in mytextlist)
            {
                IndexText(item);
                docID++;
            }
            //System.Console.WriteLine("All documents added.");
            CleanUpIndexer();
            CreateSearcher();

            List<string> score_list = SearchText(search_txt);

            return score_list;
        }



    }
}
