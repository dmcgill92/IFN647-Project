﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        int count_query = 0;
        Entry myentry = new Entry();
        Passage mypassage = new Passage();
        Overall_Collection overall_collection = new Overall_Collection();
        WindowsFormsApp1.LuceneApplication myLuceneApp = new WindowsFormsApp1.LuceneApplication();
        WindowsFormsApp1.TextAnalyser textAnalyser = new WindowsFormsApp1.TextAnalyser();
        WindowsFormsApp1.Calculate mycalculate = new WindowsFormsApp1.Calculate();
        WindowsFormsApp1.MyTextAnalyser mytextanalyser = new WindowsFormsApp1.MyTextAnalyser();
        WindowsFormsApp1.Answer myanswer = new WindowsFormsApp1.Answer();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Processing_choice.Checked = true;
            search_button.Click += Search_button_Click;
        }

        public void hightlight_Color(string[] string_list, RichTextBox myrichbox)
        {
            
            foreach (string word in string_list)
            {
                
                int starIndex = 0;
                while (starIndex < myrichbox.TextLength)
                {
                    int wordStarIndex = myrichbox.Find(word, starIndex, RichTextBoxFinds.None);
                    if (wordStarIndex != -1)
                    {
                        myrichbox.SelectionStart = wordStarIndex;
                        myrichbox.SelectionLength = word.Length;
                        myrichbox.SelectionBackColor = Color.Yellow;
                    }
                    else
                        break;
                    starIndex += wordStarIndex + word.Length;
                }

            }
        }

        private void Browse_Click(object sender, EventArgs e)
        {
            //string new_is_selected = "";
            string new_url = "";
            string new_string = "";
            string new_passge_id = "";
            //string new_string_id = "";
            string new_answer = "";
            //string new_type = "";
            string new_query = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var path = openFileDialog1.FileName;
                browse_text.Text = path;
            }
            string filePath = browse_text.Text;
            StreamReader streamReader = new StreamReader(filePath);
            JsonTextReader JTextreader = new JsonTextReader(streamReader);

            JTextreader.SupportMultipleContent = true;

            var serializer = new JsonSerializer();
            while (JTextreader.Read())
            {
                if (JTextreader.TokenType == JsonToken.StartObject)
                {

                    myentry = serializer.Deserialize<Entry>(JTextreader);


                    for (int i = 0; i < myentry.passages.Count; i++)
                    {
                        //new_is_selected = new_is_selected + myentry.passages[i].is_selected + "‰";
                        new_url = new_url + myentry.passages[i].url + "‰";
                        new_string = new_string + myentry.passages[i].passage_text + "‰";
                        new_passge_id = new_passge_id + myentry.passages[i].passage_id + "‰";
                    }
                    //new_string_id = new_string_id + myentry.query_id + "‰";
                    new_answer = new_answer + String.Join(" ", myentry.answers.ToArray()) + "‰";
                    //new_type = new_type + myentry.query_type + "‰";
                    new_query = new_query + myentry.query + "‰";
                }
            }
            //List<string> result_id = new_string_id.Split('‰').ToList();
            List<string> result_url = new_url.Split('‰').ToList();
            //List<string> result_selected = new_is_selected.Split('‰').ToList();
            List<string> result_passage_text = new_string.Split('‰').ToList();
            List<string> result_passage_id = new_passge_id.Split('‰').ToList();
            List<string> result_answer = new_answer.Split('‰').ToList();
            //List<string> result_type = new_type.Split('‰').ToList();
            List<string> result_query = new_query.Split('‰').ToList();
            int data_len = result_passage_id.Count;
            Collection mycollection = new Collection(data_len);  //To define the length of the mycollection class

            for (int i = 0; i < result_passage_id.Count; i++)  //Collect the data 
            {
                //mycollection.Selected[i] = result_selected[i];
                mycollection.Myurl[i] = result_url[i];
                mycollection.Mytext[i] = result_passage_text[i];
                mycollection.ID[i] = result_passage_id[i];
            }
            for (int i = 0; i < result_answer.Count; i++)
            {
                mycollection.Myanswer[i] = result_answer[i];
                //mycollection.QueryID[i] = result_id[i];
                //mycollection.QueryType[i] = result_type[i];
                mycollection.Query[i] = result_query[i];

            }

            //Collect the data for the whole class so that the data can be used in other method
            //overall_collection.Selected = mycollection.Selected;
            overall_collection.Myurl = mycollection.Myurl;
            overall_collection.Mytext = mycollection.Mytext;
            overall_collection.ID = mycollection.ID;
            overall_collection.Myanswer = mycollection.Myanswer;
            //overall_collection.QueryID = mycollection.QueryID;
            //overall_collection.QueryType = mycollection.QueryType;
            overall_collection.Query = mycollection.Query;


        }





        private void Browse_text_TextChanged(object sender, EventArgs e)
        {

        }


        private void FolderBrowserDialog_HelpRequest(object sender, EventArgs e)
        {

        }
        private void Save_button_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.Description = "Select where to save index";
            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                var path = folderBrowserDialog.SelectedPath;
                save_text.Text = path;

            }
        }

        private void Save_text_TextChanged(object sender, EventArgs e)
        {

        }

        private void OpenFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Create_Index_Click(object sender, EventArgs e)
        {
            string path = save_text.Text;
            List<string> index_list = new List<string>();

            for (int i = 0; i < overall_collection.Myurl.Length; i++)
            {
                if (overall_collection.Myurl[i].Length != 0)
                {
                    string title_string = myLuceneApp.GetTitle(overall_collection.Myurl[i]);

                    string[] tokens = textAnalyser.TokeniseString(title_string);
                    string[] tokensnostop = textAnalyser.StopWordFilter(tokens);
                    string final_string = String.Join(" ", tokensnostop);
                    string index_string = final_string + "‰" + overall_collection.ID[i];
                    index_list.Add(index_string);
                    
                }
            }
            Stopwatch stopwatch = Stopwatch.StartNew();
            myLuceneApp.CreateIndex(path);
            foreach (string item in index_list)
            {
                myLuceneApp.IndexText(item);
            }


            myLuceneApp.CleanUp();
            stopwatch.Stop();
            index_time.Text = stopwatch.Elapsed.TotalSeconds.ToString();

        }





        private void Query_Box_TextChanged(object sender, EventArgs e)
        {

        }

        private void Search_button_Click(object sender, EventArgs e)
        {
            search_content.Clear();
            string score_indexpath = @"C:\Users\luke666\Desktop\study\lecture\data retirve\project\score";
            string answer_path = @"C:\Users\luke666\Desktop\study\lecture\data retirve\project\answer";
            List<string> myscorelist = new List<string>();
            List<string> passge_id = new List<string>();
            List<string> passge_text = new List<string>();
            List<string> title_list = new List<string>();
            List<string> myanswerlist = new List<string>();
            List<string> answerlist = new List<string>();

            int answer_number = 0;
            for (int i = 0; i < overall_collection.Myurl.Length; i++)
            {
                if (overall_collection.Myurl[i].Length!=0)
                {
                    title_list.Add(myLuceneApp.GetTitle(overall_collection.Myurl[i]));
                }
                
            }
            string searchword = Query_Box.Text;
            if (searchword.Length!=0)
            {
                if (Processing_choice.Checked == true)
                {

                    Final_query.Text = textAnalyser.OutputTokenCountWithoutStopwords(searchword);

                    List<string> another_list = mytextanalyser.StopWordFilter(mytextanalyser.OutputTokens(searchword));
                    List<string> this_string_list = mytextanalyser.OutputStems(mytextanalyser.StopWordFilter(mytextanalyser.OutputTokens(searchword)));
                    List<string> combine_list = this_string_list.Union(another_list).ToList();
                    string string_list = string.Join(" ", mytextanalyser.OutputStems(mytextanalyser.StopWordFilter(mytextanalyser.OutputTokens(searchword))));
                    string final_combine_list = string.Join(" ", combine_list);
                    Stopwatch stopwatch = Stopwatch.StartNew();
                    myLuceneApp.CreateSearcher();
                    myLuceneApp.CreateParser();
                    List<string> retrievedResults = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(final_combine_list));
                    myLuceneApp.CleanUpSearch();
                    stopwatch.Stop();
                    Search_Time.Text = stopwatch.Elapsed.TotalSeconds.ToString();
                    
                    count_query++;
                    if (coun_time != null)
                    {
                        coun_time.Text = count_query.ToString();
                    }


                    for (int i = 0; i < retrievedResults.Count; i++)
                    {
                        passge_id.Add(retrievedResults[i].Split('‰')[1]);
                    }

                    Document_number.Text = passge_id.Count.ToString();
                    //Codes to catch the passage text

                    foreach (string item in passge_id)
                    {
                        passge_text.Add(overall_collection.Mytext[Convert.ToInt32(item)-1]);

                    }
                    foreach (var item in overall_collection.Query)
                    {
                        if (item!=null)
                        {
                            answerlist.Add(item);
                        }
                        

                    }
                    myscorelist = mycalculate.return_score(score_indexpath, final_combine_list, passge_text);
                    myanswerlist = myanswer.return_answer_query(answer_path, final_combine_list, answerlist);
                    if (myanswerlist.Count !=0)
                    {
                        for (int i = 0; i < overall_collection.Myanswer.Length; i++)
                        {

                            if (myanswerlist[0] == overall_collection.Query[i])
                            {
                                answer_number = i;
                            }
                        }
                    }
                    
                    Target_answer.Text = "--->Query: " +"\n"+ overall_collection.Query[answer_number] + "\n" + "--->Answer: " + "\n"+overall_collection.Myanswer[answer_number]
                        + "\n" + "\n";
                    


                    for (int i = 0; i < passge_text.Count; i++)
                    {

                        int c = i + 1;
                        search_content.Text = search_content.Text + "--->Rank: " + c + "\n" + "--->Document ID: " + passge_id[i] + "\n" + "--->Title: " + title_list[Convert.ToInt32(passge_id[i])-1] + "\n"
                            + "--->URL: " + overall_collection.Myurl[Convert.ToInt32(passge_id[i])-1] + "\n" + "--->Passage Text: " + "\n" + passge_text[i] + "\n" + "\n" + "\n" + "\n";

                    }

                    for (int i = 0; i < myscorelist.Count; i++)
                    {
                        int c=i+1;
                        baseline_result.Text = baseline_result.Text + count_query.ToString("000") + "    " + "Q0" + "    " + passge_id[i] + "    " + c + "    " + myscorelist[i] + "    " + "BaseLine" + "\n";

                    }
                    hightlight_Color(final_combine_list.Split(' '), search_content);
                }


                else if (Without_Process.Checked == true)
                {
                    
                    Final_query.Text = String.Join(" ",mytextanalyser.TokeniseString(Query_Box.Text));

                    Stopwatch stopwatch = Stopwatch.StartNew();
                    myLuceneApp.CreateSearcher();
                    myLuceneApp.CreateParser();
                    List<string> retrievedResults = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(Final_query.Text));
                    myLuceneApp.CleanUpSearch();
                    stopwatch.Stop();
                    Search_Time.Text = stopwatch.Elapsed.TotalSeconds.ToString();
                    count_query++;
                    if (coun_time != null)
                    {
                        coun_time.Text = count_query.ToString();
                    }


                    for (int i = 0; i < retrievedResults.Count; i++)
                    {
                        passge_id.Add(retrievedResults[i].Split('‰')[1]);
                    }

                    Document_number.Text = passge_id.Count.ToString();
                    //Codes to catch the passage text

                    foreach (string item in passge_id)
                    {
                        passge_text.Add(overall_collection.Mytext[Convert.ToInt32(item) - 1]);

                    }
                    foreach (var item in overall_collection.Query)
                    {
                        if (item != null)
                        {
                            answerlist.Add(item);
                        }


                    }
                    myscorelist = mycalculate.return_score(score_indexpath, Final_query.Text, passge_text);
                    myanswerlist = myanswer.return_answer_query(answer_path, Final_query.Text, answerlist);
                    if (myanswerlist.Count !=0)
                    {
                        for (int i = 0; i < overall_collection.Myanswer.Length; i++)
                        {
                            if (myanswerlist[0] == overall_collection.Query[i])
                            {
                                Console.WriteLine(i);
                                answer_number = i;
                            }
                        }
                    }
                    
                    Target_answer.Text = "--->Query: " + "\n" + overall_collection.Query[answer_number] + "\n" + "--->Answer: " + "\n" + overall_collection.Myanswer[answer_number]
                        + "\n" + "\n";



                    for (int i = 0; i < passge_text.Count; i++)
                    {

                        int c = i + 1;
                        search_content.Text = search_content.Text + "--->Rank: " + c + "\n" + "--->Document ID: " + passge_id[i] + "\n" + "--->Title: " + title_list[Convert.ToInt32(passge_id[i]) - 1] + "\n"
                            + "--->URL: " + overall_collection.Myurl[Convert.ToInt32(passge_id[i]) - 1] + "\n" + "--->Passage Text: " + "\n" + passge_text[i] + "\n" + "\n" + "\n" + "\n";

                    }

                    for (int i = 0; i < myscorelist.Count; i++)
                    {
                        int c = i + 1;
                        baseline_result.Text = baseline_result.Text + count_query.ToString("000") + "    " + "Q0" + "    " + passge_id[i] + "    " + c + "    " + myscorelist[i] + "    " + "BaseLine" + "\n";

                    }
                    hightlight_Color(Final_query.Text.Split(' '), search_content);
                }

            }

            
            
           
        }

        private void Search_content_TextChanged(object sender, EventArgs e)
        {

        }

        private void Index_time_Click(object sender, EventArgs e)
        {

        }

        private void Final_query_TextChanged(object sender, EventArgs e)
        {

        }

        private void Processing_choice_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Without_Process_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void TblResults_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Search_Time_Click(object sender, EventArgs e)
        {

        }

        private void Document_number_Click(object sender, EventArgs e)
        {

        }

        private void Baseline_result_TextChanged(object sender, EventArgs e)
        {

        }

        private void Coun_time_Click(object sender, EventArgs e)
        {

        }

        private void Save_Result_Click(object sender, EventArgs e)
        {
            DialogResult result = save_baseline.ShowDialog();
            if (result == DialogResult.OK)
            {
                string name = save_baseline.FileName;
                File.WriteAllText(name, baseline_result.Text);
            }
        }

        private void Save_baseline_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Index_Size_Click(object sender, EventArgs e)
        {

        }

        private void Label13_Click(object sender, EventArgs e)
        {

        }

        private void Label14_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void Target_answer_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
