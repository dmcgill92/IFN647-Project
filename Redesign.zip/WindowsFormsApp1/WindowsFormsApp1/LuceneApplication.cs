﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net.Analysis; // for Analyser
using Lucene.Net.Documents; // for Socument
using Lucene.Net.Index; //for Index Writer
using Lucene.Net.QueryParsers;
using Lucene.Net.Search;
using Lucene.Net.Store; //for Directory

namespace WindowsFormsApp1
{
    class LuceneApplication
    {
        Lucene.Net.Store.Directory luceneIndexDirectory;
        Lucene.Net.Analysis.Analyzer analyzer;
        Lucene.Net.Index.IndexWriter writer;
        Lucene.Net.Search.IndexSearcher searcher;
        Lucene.Net.QueryParsers.QueryParser parser;

        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TEXT_FN = "Text";
        public LuceneApplication()
        {
            luceneIndexDirectory = null; // Is set in Create Index
            analyzer = null;  // Is set in CreateAnalyser
            writer = null; // Is set in CreateWriter
        }
        public string GetTitle(string url)
        {
            string[] fragments = url.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            string title = fragments.Last();
            fragments = title.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);
            if (fragments.Length > 1)
            {
                var sorted = fragments.OrderBy(n => n.Length);
                title = sorted.LastOrDefault();
            }
            title = title.Replace('-', ' ');
            title = title.Replace('_', ' ');
            TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
            title = textInfo.ToTitleCase(title);

            return title;
        }

        public void CreateIndex(string indexPath)
        {
            luceneIndexDirectory = Lucene.Net.Store.FSDirectory.Open(indexPath);
            analyzer = new Lucene.Net.Analysis.Standard.StandardAnalyzer(VERSION);
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            //IndexDeletionPolicy p;

            writer = new Lucene.Net.Index.IndexWriter(luceneIndexDirectory, analyzer, true, mfl);

        }



        public void IndexText(string text)
        {


            Lucene.Net.Documents.Field field = new Field(TEXT_FN, text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.WITH_POSITIONS_OFFSETS);
            Lucene.Net.Documents.Document doc = new Document();
            doc.Add(field);
            writer.AddDocument(doc);
        }


        public void CleanUp()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }


        public void CreateSearcher()
        {
            searcher = new IndexSearcher(luceneIndexDirectory);
        }

        public void CreateParser()
        {
            parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TEXT_FN, analyzer);
        }


        public void CleanUpSearch()
        {
            searcher.Dispose();
        }


        public TopDocs SearchIndex(string querytext)
        {

            querytext = querytext.ToLower();
            Query query = parser.Parse(querytext);
            TopDocs results = searcher.Search(query, 100);
            //System.Console.WriteLine("Number of results is " + results.TotalHits);
            return results;

        }

        public List<string> DisplayResults(TopDocs results)
        {
            int rank = 0;
            List<string> retrievedResults = new List<string>();
            foreach (ScoreDoc scoreDoc in results.ScoreDocs)
            {
                rank++;
                // retrieve the document from the 'ScoreDoc' object
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);
                //Console.WriteLine(doc);
                string myFieldValue = doc.Get(TEXT_FN).ToString();
                //Console.WriteLine("Rank " + rank + " score " + scoreDoc.Score + " text " + myFieldValue);
                //Console.WriteLine("Rank " + rank + " text " + myFieldValue);
                retrievedResults.Add("Rank " + rank + " score " + scoreDoc.Score + " text " + myFieldValue);
            }
            return retrievedResults;
        }






    }
}