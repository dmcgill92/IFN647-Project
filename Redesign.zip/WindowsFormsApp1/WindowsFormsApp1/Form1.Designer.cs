﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Browse = new System.Windows.Forms.Button();
            this.browse_text = new System.Windows.Forms.TextBox();
            this.save_button = new System.Windows.Forms.Button();
            this.save_text = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.Create_Index = new System.Windows.Forms.Button();
            this.search_button = new System.Windows.Forms.Button();
            this.Query_Box = new System.Windows.Forms.TextBox();
            this.search_content = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.index_time = new System.Windows.Forms.Label();
            this.Final_query = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Processing_choice = new System.Windows.Forms.RadioButton();
            this.Without_Process = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.Search_Time = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Document_number = new System.Windows.Forms.Label();
            this.baseline_result = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.coun_time = new System.Windows.Forms.Label();
            this.Save_Result = new System.Windows.Forms.Button();
            this.save_baseline = new System.Windows.Forms.SaveFileDialog();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.Target_answer = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Browse
            // 
            this.Browse.Location = new System.Drawing.Point(12, 18);
            this.Browse.Name = "Browse";
            this.Browse.Size = new System.Drawing.Size(136, 37);
            this.Browse.TabIndex = 0;
            this.Browse.Text = "Browse Location";
            this.Browse.UseVisualStyleBackColor = true;
            this.Browse.Click += new System.EventHandler(this.Browse_Click);
            // 
            // browse_text
            // 
            this.browse_text.Location = new System.Drawing.Point(169, 26);
            this.browse_text.Name = "browse_text";
            this.browse_text.Size = new System.Drawing.Size(178, 25);
            this.browse_text.TabIndex = 1;
            this.browse_text.TextChanged += new System.EventHandler(this.Browse_text_TextChanged);
            // 
            // save_button
            // 
            this.save_button.Location = new System.Drawing.Point(12, 105);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(136, 35);
            this.save_button.TabIndex = 2;
            this.save_button.Text = "Index Location";
            this.save_button.UseVisualStyleBackColor = true;
            this.save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // save_text
            // 
            this.save_text.Location = new System.Drawing.Point(169, 105);
            this.save_text.Name = "save_text";
            this.save_text.Size = new System.Drawing.Size(178, 25);
            this.save_text.TabIndex = 3;
            this.save_text.TextChanged += new System.EventHandler(this.Save_text_TextChanged);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog1_FileOk);
            // 
            // folderBrowserDialog
            // 
            this.folderBrowserDialog.HelpRequest += new System.EventHandler(this.FolderBrowserDialog_HelpRequest);
            // 
            // Create_Index
            // 
            this.Create_Index.Location = new System.Drawing.Point(12, 185);
            this.Create_Index.Name = "Create_Index";
            this.Create_Index.Size = new System.Drawing.Size(335, 57);
            this.Create_Index.TabIndex = 4;
            this.Create_Index.Text = "Create Index";
            this.Create_Index.UseVisualStyleBackColor = true;
            this.Create_Index.Click += new System.EventHandler(this.Create_Index_Click);
            // 
            // search_button
            // 
            this.search_button.Location = new System.Drawing.Point(1246, 12);
            this.search_button.Name = "search_button";
            this.search_button.Size = new System.Drawing.Size(137, 43);
            this.search_button.TabIndex = 5;
            this.search_button.Text = "Search";
            this.search_button.UseVisualStyleBackColor = true;
            this.search_button.Click += new System.EventHandler(this.Search_button_Click);
            // 
            // Query_Box
            // 
            this.Query_Box.Location = new System.Drawing.Point(530, 13);
            this.Query_Box.Name = "Query_Box";
            this.Query_Box.Size = new System.Drawing.Size(511, 25);
            this.Query_Box.TabIndex = 6;
            this.Query_Box.TextChanged += new System.EventHandler(this.Query_Box_TextChanged);
            // 
            // search_content
            // 
            this.search_content.Location = new System.Drawing.Point(421, 436);
            this.search_content.Name = "search_content";
            this.search_content.Size = new System.Drawing.Size(962, 343);
            this.search_content.TabIndex = 7;
            this.search_content.Text = "";
            this.search_content.TextChanged += new System.EventHandler(this.Search_content_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 313);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "Index Time";
            // 
            // index_time
            // 
            this.index_time.AutoSize = true;
            this.index_time.Location = new System.Drawing.Point(214, 313);
            this.index_time.Name = "index_time";
            this.index_time.Size = new System.Drawing.Size(15, 15);
            this.index_time.TabIndex = 9;
            this.index_time.Text = "0";
            this.index_time.Click += new System.EventHandler(this.Index_time_Click);
            // 
            // Final_query
            // 
            this.Final_query.Location = new System.Drawing.Point(530, 57);
            this.Final_query.Name = "Final_query";
            this.Final_query.Size = new System.Drawing.Size(511, 25);
            this.Final_query.TabIndex = 10;
            this.Final_query.TextChanged += new System.EventHandler(this.Final_query_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(418, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "Final_Query";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(418, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Search Text";
            // 
            // Processing_choice
            // 
            this.Processing_choice.AutoSize = true;
            this.Processing_choice.Location = new System.Drawing.Point(1075, 14);
            this.Processing_choice.Name = "Processing_choice";
            this.Processing_choice.Size = new System.Drawing.Size(124, 19);
            this.Processing_choice.TabIndex = 13;
            this.Processing_choice.TabStop = true;
            this.Processing_choice.Text = "Process Text";
            this.Processing_choice.UseVisualStyleBackColor = true;
            this.Processing_choice.CheckedChanged += new System.EventHandler(this.Processing_choice_CheckedChanged);
            // 
            // Without_Process
            // 
            this.Without_Process.AutoSize = true;
            this.Without_Process.Location = new System.Drawing.Point(1075, 58);
            this.Without_Process.Name = "Without_Process";
            this.Without_Process.Size = new System.Drawing.Size(108, 19);
            this.Without_Process.TabIndex = 14;
            this.Without_Process.TabStop = true;
            this.Without_Process.Text = "No Process";
            this.Without_Process.UseVisualStyleBackColor = true;
            this.Without_Process.CheckedChanged += new System.EventHandler(this.Without_Process_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 353);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 15);
            this.label4.TabIndex = 15;
            this.label4.Text = "Search Time";
            // 
            // Search_Time
            // 
            this.Search_Time.AutoSize = true;
            this.Search_Time.Location = new System.Drawing.Point(214, 353);
            this.Search_Time.Name = "Search_Time";
            this.Search_Time.Size = new System.Drawing.Size(15, 15);
            this.Search_Time.TabIndex = 16;
            this.Search_Time.Text = "0";
            this.Search_Time.Click += new System.EventHandler(this.Search_Time_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 436);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 15);
            this.label5.TabIndex = 17;
            this.label5.Text = "Document Numbers";
            // 
            // Document_number
            // 
            this.Document_number.AutoSize = true;
            this.Document_number.Location = new System.Drawing.Point(214, 436);
            this.Document_number.Name = "Document_number";
            this.Document_number.Size = new System.Drawing.Size(15, 15);
            this.Document_number.TabIndex = 18;
            this.Document_number.Text = "0";
            this.Document_number.Click += new System.EventHandler(this.Document_number_Click);
            // 
            // baseline_result
            // 
            this.baseline_result.Location = new System.Drawing.Point(421, 158);
            this.baseline_result.Name = "baseline_result";
            this.baseline_result.Size = new System.Drawing.Size(441, 210);
            this.baseline_result.TabIndex = 19;
            this.baseline_result.Text = "";
            this.baseline_result.TextChanged += new System.EventHandler(this.Baseline_result_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 398);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 15);
            this.label6.TabIndex = 20;
            this.label6.Text = "Search Times";
            // 
            // coun_time
            // 
            this.coun_time.AutoSize = true;
            this.coun_time.Location = new System.Drawing.Point(214, 398);
            this.coun_time.Name = "coun_time";
            this.coun_time.Size = new System.Drawing.Size(15, 15);
            this.coun_time.TabIndex = 21;
            this.coun_time.Text = "0";
            this.coun_time.Click += new System.EventHandler(this.Coun_time_Click);
            // 
            // Save_Result
            // 
            this.Save_Result.Location = new System.Drawing.Point(1246, 94);
            this.Save_Result.Name = "Save_Result";
            this.Save_Result.Size = new System.Drawing.Size(137, 46);
            this.Save_Result.TabIndex = 22;
            this.Save_Result.Text = "Save";
            this.Save_Result.UseVisualStyleBackColor = true;
            this.Save_Result.Click += new System.EventHandler(this.Save_Result_Click);
            // 
            // save_baseline
            // 
            this.save_baseline.FileOk += new System.ComponentModel.CancelEventHandler(this.Save_baseline_FileOk);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(77, 543);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(119, 15);
            this.label8.TabIndex = 25;
            this.label8.Text = "Using Guidance";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 583);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(279, 15);
            this.label9.TabIndex = 26;
            this.label9.Text = "1. Browsing the json file location";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 619);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(311, 15);
            this.label10.TabIndex = 27;
            this.label10.Text = "2. Choosing the Location to save index";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 650);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(247, 15);
            this.label11.TabIndex = 28;
            this.label11.Text = "3. Clicking Creat Index button";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 681);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(303, 15);
            this.label12.TabIndex = 29;
            this.label12.Text = "4. Writing contents in the search box";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 747);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(239, 15);
            this.label13.TabIndex = 30;
            this.label13.Text = "6. Clicking the search button";
            this.label13.Click += new System.EventHandler(this.Label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 774);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(391, 15);
            this.label14.TabIndex = 31;
            this.label14.Text = "7. Clicking the save button to save your results";
            this.label14.Click += new System.EventHandler(this.Label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(101, 275);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(79, 15);
            this.label15.TabIndex = 32;
            this.label15.Text = "Diagnoses";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 714);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(303, 15);
            this.label16.TabIndex = 33;
            this.label16.Text = "5. Choosing how do you want to search";
            // 
            // Target_answer
            // 
            this.Target_answer.Location = new System.Drawing.Point(906, 158);
            this.Target_answer.Name = "Target_answer";
            this.Target_answer.Size = new System.Drawing.Size(477, 210);
            this.Target_answer.TabIndex = 34;
            this.Target_answer.Text = "";
            this.Target_answer.TextChanged += new System.EventHandler(this.Target_answer_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(418, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 15);
            this.label7.TabIndex = 35;
            this.label7.Text = "BaseLine Result";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(903, 125);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(135, 15);
            this.label17.TabIndex = 36;
            this.label17.Text = "Query and Answer";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(418, 398);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(127, 15);
            this.label18.TabIndex = 37;
            this.label18.Text = "Relevant Result";
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1417, 862);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Target_answer);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Save_Result);
            this.Controls.Add(this.coun_time);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.baseline_result);
            this.Controls.Add(this.Document_number);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Search_Time);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Without_Process);
            this.Controls.Add(this.Processing_choice);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Final_query);
            this.Controls.Add(this.index_time);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.search_content);
            this.Controls.Add(this.Query_Box);
            this.Controls.Add(this.search_button);
            this.Controls.Add(this.Create_Index);
            this.Controls.Add(this.save_text);
            this.Controls.Add(this.save_button);
            this.Controls.Add(this.browse_text);
            this.Controls.Add(this.Browse);
            this.Name = "Form1";
            this.Text = "Browse";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Browse;
        private System.Windows.Forms.TextBox browse_text;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.TextBox save_text;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button Create_Index;
        private System.Windows.Forms.Button search_button;
        private System.Windows.Forms.TextBox Query_Box;
        private System.Windows.Forms.RichTextBox search_content;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label index_time;
        private System.Windows.Forms.TextBox Final_query;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton Processing_choice;
        private System.Windows.Forms.RadioButton Without_Process;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Search_Time;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Document_number;
        private System.Windows.Forms.RichTextBox baseline_result;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label coun_time;
        private System.Windows.Forms.Button Save_Result;
        private System.Windows.Forms.SaveFileDialog save_baseline;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RichTextBox Target_answer;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
    }
}

