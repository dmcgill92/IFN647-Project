﻿namespace IFN647_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblSearch1;
            System.Windows.Forms.Label lblSearch2;
            System.Windows.Forms.Label lblQueryResults;
            System.Windows.Forms.Label lblAllResults;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtCollectionFile = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblCollectionFile = new System.Windows.Forms.Label();
            this.txtIndexFile = new System.Windows.Forms.TextBox();
            this.btnBrowse2 = new System.Windows.Forms.Button();
            this.lblIndexSave = new System.Windows.Forms.Label();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.btnCreateIndex = new System.Windows.Forms.Button();
            this.txtSearchContent1 = new System.Windows.Forms.TextBox();
            this.btnSearch1 = new System.Windows.Forms.Button();
            this.lblQueryGenTimeResult = new System.Windows.Forms.Label();
            this.lblIndexTime = new System.Windows.Forms.Label();
            this.lblQueryGenTime = new System.Windows.Forms.Label();
            this.lblSearchingTimesResult = new System.Windows.Forms.Label();
            this.lblFinalQuery = new System.Windows.Forms.Label();
            this.lblNumRelDocs = new System.Windows.Forms.Label();
            this.lblNumRelDocsResult = new System.Windows.Forms.Label();
            this.txtFinalQuery = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lblSearchingTimes = new System.Windows.Forms.Label();
            this.lblIndexTimeResult = new System.Windows.Forms.Label();
            this.pnlIndex = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlSearchHome = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSuggestions1 = new System.Windows.Forms.Label();
            this.cmbbxBoosting1 = new System.Windows.Forms.ComboBox();
            this.chkbxQueryExpansion1 = new System.Windows.Forms.CheckBox();
            this.chkbxProcessing1 = new System.Windows.Forms.CheckBox();
            this.pnlSearch = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabSearch = new System.Windows.Forms.TabPage();
            this.pnlSearchResults = new System.Windows.Forms.Panel();
            this.cmbbxBoosting2 = new System.Windows.Forms.ComboBox();
            this.tblResults = new System.Windows.Forms.TableLayoutPanel();
            this.txtSearchContent2 = new System.Windows.Forms.TextBox();
            this.btnSearch2 = new System.Windows.Forms.Button();
            this.chkbxQueryExpansion2 = new System.Windows.Forms.CheckBox();
            this.chkbxProcessing2 = new System.Windows.Forms.CheckBox();
            this.tabDiagnostics = new System.Windows.Forms.TabPage();
            this.txtQueryResults = new System.Windows.Forms.RichTextBox();
            this.txtAllResults = new System.Windows.Forms.RichTextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.imglstDropdown = new System.Windows.Forms.ImageList(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            lblSearch1 = new System.Windows.Forms.Label();
            lblSearch2 = new System.Windows.Forms.Label();
            lblQueryResults = new System.Windows.Forms.Label();
            lblAllResults = new System.Windows.Forms.Label();
            this.pnlIndex.SuspendLayout();
            this.pnlSearchHome.SuspendLayout();
            this.pnlSearch.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabSearch.SuspendLayout();
            this.pnlSearchResults.SuspendLayout();
            this.tabDiagnostics.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSearch1
            // 
            lblSearch1.Anchor = System.Windows.Forms.AnchorStyles.None;
            lblSearch1.AutoSize = true;
            lblSearch1.Location = new System.Drawing.Point(698, 234);
            lblSearch1.Name = "lblSearch1";
            lblSearch1.Size = new System.Drawing.Size(167, 15);
            lblSearch1.TabIndex = 4;
            lblSearch1.Text = "Input Search Content";
            // 
            // lblSearch2
            // 
            lblSearch2.AutoSize = true;
            lblSearch2.Location = new System.Drawing.Point(12, 20);
            lblSearch2.Name = "lblSearch2";
            lblSearch2.Size = new System.Drawing.Size(167, 15);
            lblSearch2.TabIndex = 32;
            lblSearch2.Text = "Input Search Content";
            // 
            // lblQueryResults
            // 
            lblQueryResults.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            lblQueryResults.Location = new System.Drawing.Point(27, 115);
            lblQueryResults.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblQueryResults.Name = "lblQueryResults";
            lblQueryResults.Size = new System.Drawing.Size(732, 15);
            lblQueryResults.TabIndex = 27;
            lblQueryResults.Text = "Results for current query";
            // 
            // lblAllResults
            // 
            lblAllResults.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            lblAllResults.Location = new System.Drawing.Point(783, 112);
            lblAllResults.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblAllResults.Name = "lblAllResults";
            lblAllResults.Size = new System.Drawing.Size(732, 15);
            lblAllResults.TabIndex = 27;
            lblAllResults.Text = "Results for current session";
            // 
            // txtCollectionFile
            // 
            this.txtCollectionFile.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCollectionFile.Location = new System.Drawing.Point(515, 134);
            this.txtCollectionFile.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtCollectionFile.Name = "txtCollectionFile";
            this.txtCollectionFile.ReadOnly = true;
            this.txtCollectionFile.Size = new System.Drawing.Size(527, 25);
            this.txtCollectionFile.TabIndex = 0;
            this.txtCollectionFile.TextChanged += new System.EventHandler(this.TxtCollectionFile_TextChanged);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnBrowse.Location = new System.Drawing.Point(724, 164);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(109, 35);
            this.btnBrowse.TabIndex = 1;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.BtnBrowse_Click);
            // 
            // lblCollectionFile
            // 
            this.lblCollectionFile.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblCollectionFile.AutoSize = true;
            this.lblCollectionFile.Location = new System.Drawing.Point(715, 114);
            this.lblCollectionFile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCollectionFile.Name = "lblCollectionFile";
            this.lblCollectionFile.Size = new System.Drawing.Size(159, 15);
            this.lblCollectionFile.TabIndex = 2;
            this.lblCollectionFile.Text = "Collection Location";
            // 
            // txtIndexFile
            // 
            this.txtIndexFile.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtIndexFile.Location = new System.Drawing.Point(515, 285);
            this.txtIndexFile.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtIndexFile.Name = "txtIndexFile";
            this.txtIndexFile.ReadOnly = true;
            this.txtIndexFile.Size = new System.Drawing.Size(527, 25);
            this.txtIndexFile.TabIndex = 0;
            this.txtIndexFile.TextChanged += new System.EventHandler(this.TxtIndexFile_TextChanged);
            // 
            // btnBrowse2
            // 
            this.btnBrowse2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnBrowse2.Location = new System.Drawing.Point(725, 313);
            this.btnBrowse2.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnBrowse2.Name = "btnBrowse2";
            this.btnBrowse2.Size = new System.Drawing.Size(108, 35);
            this.btnBrowse2.TabIndex = 1;
            this.btnBrowse2.Text = "Browse";
            this.btnBrowse2.UseVisualStyleBackColor = true;
            this.btnBrowse2.Click += new System.EventHandler(this.BtnBrowse2_Click);
            // 
            // lblIndexSave
            // 
            this.lblIndexSave.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblIndexSave.AutoSize = true;
            this.lblIndexSave.Location = new System.Drawing.Point(709, 268);
            this.lblIndexSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndexSave.Name = "lblIndexSave";
            this.lblIndexSave.Size = new System.Drawing.Size(159, 15);
            this.lblIndexSave.TabIndex = 2;
            this.lblIndexSave.Text = "Index Save Location";
            // 
            // btnCreateIndex
            // 
            this.btnCreateIndex.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCreateIndex.Enabled = false;
            this.btnCreateIndex.Location = new System.Drawing.Point(1425, 617);
            this.btnCreateIndex.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnCreateIndex.Name = "btnCreateIndex";
            this.btnCreateIndex.Size = new System.Drawing.Size(109, 35);
            this.btnCreateIndex.TabIndex = 1;
            this.btnCreateIndex.Text = "Create Index";
            this.btnCreateIndex.UseVisualStyleBackColor = true;
            this.btnCreateIndex.Click += new System.EventHandler(this.BtnCreateIndex_Click);
            // 
            // txtSearchContent1
            // 
            this.txtSearchContent1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSearchContent1.Location = new System.Drawing.Point(440, 264);
            this.txtSearchContent1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSearchContent1.Name = "txtSearchContent1";
            this.txtSearchContent1.Size = new System.Drawing.Size(660, 25);
            this.txtSearchContent1.TabIndex = 3;
            this.txtSearchContent1.TextChanged += new System.EventHandler(this.TxtSearchContent1_TextChanged);
            // 
            // btnSearch1
            // 
            this.btnSearch1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnSearch1.Enabled = false;
            this.btnSearch1.Location = new System.Drawing.Point(717, 425);
            this.btnSearch1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch1.Name = "btnSearch1";
            this.btnSearch1.Size = new System.Drawing.Size(104, 31);
            this.btnSearch1.TabIndex = 5;
            this.btnSearch1.Text = "Search";
            this.btnSearch1.UseMnemonic = false;
            this.btnSearch1.UseVisualStyleBackColor = true;
            this.btnSearch1.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // lblQueryGenTimeResult
            // 
            this.lblQueryGenTimeResult.AutoSize = true;
            this.lblQueryGenTimeResult.Location = new System.Drawing.Point(211, 48);
            this.lblQueryGenTimeResult.Name = "lblQueryGenTimeResult";
            this.lblQueryGenTimeResult.Size = new System.Drawing.Size(15, 15);
            this.lblQueryGenTimeResult.TabIndex = 6;
            this.lblQueryGenTimeResult.Text = "0";
            // 
            // lblIndexTime
            // 
            this.lblIndexTime.AutoSize = true;
            this.lblIndexTime.Location = new System.Drawing.Point(392, 22);
            this.lblIndexTime.Name = "lblIndexTime";
            this.lblIndexTime.Size = new System.Drawing.Size(167, 15);
            this.lblIndexTime.TabIndex = 9;
            this.lblIndexTime.Text = "Time for indexing:  ";
            // 
            // lblQueryGenTime
            // 
            this.lblQueryGenTime.AutoSize = true;
            this.lblQueryGenTime.Location = new System.Drawing.Point(27, 48);
            this.lblQueryGenTime.Name = "lblQueryGenTime";
            this.lblQueryGenTime.Size = new System.Drawing.Size(175, 15);
            this.lblQueryGenTime.TabIndex = 10;
            this.lblQueryGenTime.Text = "Time to create query:";
            // 
            // lblSearchingTimesResult
            // 
            this.lblSearchingTimesResult.AutoSize = true;
            this.lblSearchingTimesResult.Location = new System.Drawing.Point(576, 50);
            this.lblSearchingTimesResult.Name = "lblSearchingTimesResult";
            this.lblSearchingTimesResult.Size = new System.Drawing.Size(15, 15);
            this.lblSearchingTimesResult.TabIndex = 11;
            this.lblSearchingTimesResult.Text = "0";
            // 
            // lblFinalQuery
            // 
            this.lblFinalQuery.AutoSize = true;
            this.lblFinalQuery.Location = new System.Drawing.Point(623, 20);
            this.lblFinalQuery.Name = "lblFinalQuery";
            this.lblFinalQuery.Size = new System.Drawing.Size(127, 15);
            this.lblFinalQuery.TabIndex = 12;
            this.lblFinalQuery.Text = "Processed Query";
            // 
            // lblNumRelDocs
            // 
            this.lblNumRelDocs.AutoSize = true;
            this.lblNumRelDocs.Location = new System.Drawing.Point(27, 22);
            this.lblNumRelDocs.Name = "lblNumRelDocs";
            this.lblNumRelDocs.Size = new System.Drawing.Size(223, 15);
            this.lblNumRelDocs.TabIndex = 14;
            this.lblNumRelDocs.Text = "Number of relevant results:";
            // 
            // lblNumRelDocsResult
            // 
            this.lblNumRelDocsResult.AutoSize = true;
            this.lblNumRelDocsResult.Location = new System.Drawing.Point(211, 22);
            this.lblNumRelDocsResult.Name = "lblNumRelDocsResult";
            this.lblNumRelDocsResult.Size = new System.Drawing.Size(15, 15);
            this.lblNumRelDocsResult.TabIndex = 15;
            this.lblNumRelDocsResult.Text = "0";
            // 
            // txtFinalQuery
            // 
            this.txtFinalQuery.Location = new System.Drawing.Point(627, 38);
            this.txtFinalQuery.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtFinalQuery.Multiline = true;
            this.txtFinalQuery.Name = "txtFinalQuery";
            this.txtFinalQuery.ReadOnly = true;
            this.txtFinalQuery.Size = new System.Drawing.Size(865, 72);
            this.txtFinalQuery.TabIndex = 20;
            // 
            // lblSearchingTimes
            // 
            this.lblSearchingTimes.AutoSize = true;
            this.lblSearchingTimes.Location = new System.Drawing.Point(392, 50);
            this.lblSearchingTimes.Name = "lblSearchingTimes";
            this.lblSearchingTimes.Size = new System.Drawing.Size(127, 15);
            this.lblSearchingTimes.TabIndex = 24;
            this.lblSearchingTimes.Text = "Time to search:";
            // 
            // lblIndexTimeResult
            // 
            this.lblIndexTimeResult.AutoSize = true;
            this.lblIndexTimeResult.Location = new System.Drawing.Point(576, 22);
            this.lblIndexTimeResult.Name = "lblIndexTimeResult";
            this.lblIndexTimeResult.Size = new System.Drawing.Size(15, 15);
            this.lblIndexTimeResult.TabIndex = 25;
            this.lblIndexTimeResult.Text = "0";
            // 
            // pnlIndex
            // 
            this.pnlIndex.Controls.Add(this.label3);
            this.pnlIndex.Controls.Add(this.label2);
            this.pnlIndex.Controls.Add(this.label1);
            this.pnlIndex.Controls.Add(this.txtCollectionFile);
            this.pnlIndex.Controls.Add(this.btnBrowse);
            this.pnlIndex.Controls.Add(this.lblCollectionFile);
            this.pnlIndex.Controls.Add(this.lblIndexSave);
            this.pnlIndex.Controls.Add(this.txtIndexFile);
            this.pnlIndex.Controls.Add(this.btnBrowse2);
            this.pnlIndex.Controls.Add(this.btnCreateIndex);
            this.pnlIndex.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlIndex.Location = new System.Drawing.Point(0, 0);
            this.pnlIndex.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlIndex.Name = "pnlIndex";
            this.pnlIndex.Size = new System.Drawing.Size(1557, 678);
            this.pnlIndex.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Info;
            this.label3.Location = new System.Drawing.Point(1162, 627);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(239, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Click to create the index-->>";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Info;
            this.label2.Location = new System.Drawing.Point(877, 326);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(311, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "<<--Click to save the index\'s location";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Info;
            this.label1.Location = new System.Drawing.Point(877, 174);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(359, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "<<--Click to browse the json file\'s location";
            // 
            // pnlSearchHome
            // 
            this.pnlSearchHome.Controls.Add(this.label7);
            this.pnlSearchHome.Controls.Add(this.label6);
            this.pnlSearchHome.Controls.Add(this.label5);
            this.pnlSearchHome.Controls.Add(this.label4);
            this.pnlSearchHome.Controls.Add(this.lblSuggestions1);
            this.pnlSearchHome.Controls.Add(this.cmbbxBoosting1);
            this.pnlSearchHome.Controls.Add(this.chkbxQueryExpansion1);
            this.pnlSearchHome.Controls.Add(this.chkbxProcessing1);
            this.pnlSearchHome.Controls.Add(lblSearch1);
            this.pnlSearchHome.Controls.Add(this.txtSearchContent1);
            this.pnlSearchHome.Controls.Add(this.btnSearch1);
            this.pnlSearchHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSearchHome.Location = new System.Drawing.Point(4, 3);
            this.pnlSearchHome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlSearchHome.Name = "pnlSearchHome";
            this.pnlSearchHome.Size = new System.Drawing.Size(1541, 643);
            this.pnlSearchHome.TabIndex = 40;
            this.pnlSearchHome.Paint += new System.Windows.Forms.PaintEventHandler(this.PnlSearchHome_Paint);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Info;
            this.label7.Location = new System.Drawing.Point(926, 393);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 15);
            this.label7.TabIndex = 46;
            this.label7.Text = "<<-- Field boost";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Info;
            this.label6.Location = new System.Drawing.Point(901, 358);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(375, 15);
            this.label6.TabIndex = 45;
            this.label6.Text = "<<-- Choose if you want to get query expansion";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Info;
            this.label5.Location = new System.Drawing.Point(901, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(359, 15);
            this.label5.TabIndex = 44;
            this.label5.Text = "<<-- Choose if you want to process the query";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Info;
            this.label4.Location = new System.Drawing.Point(1132, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 15);
            this.label4.TabIndex = 43;
            this.label4.Text = "<<-- Input your searching contents";
            // 
            // lblSuggestions1
            // 
            this.lblSuggestions1.Location = new System.Drawing.Point(439, 294);
            this.lblSuggestions1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSuggestions1.Name = "lblSuggestions1";
            this.lblSuggestions1.Size = new System.Drawing.Size(661, 23);
            this.lblSuggestions1.TabIndex = 42;
            this.lblSuggestions1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbbxBoosting1
            // 
            this.cmbbxBoosting1.FormattingEnabled = true;
            this.cmbbxBoosting1.Items.AddRange(new object[] {
            "No Boosting",
            "Title Boosting",
            "Query Boosting"});
            this.cmbbxBoosting1.Location = new System.Drawing.Point(631, 390);
            this.cmbbxBoosting1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbbxBoosting1.Name = "cmbbxBoosting1";
            this.cmbbxBoosting1.Size = new System.Drawing.Size(277, 23);
            this.cmbbxBoosting1.TabIndex = 41;
            this.cmbbxBoosting1.SelectedIndexChanged += new System.EventHandler(this.CmbbxBoosting1_SelectedIndexChanged);
            // 
            // chkbxQueryExpansion1
            // 
            this.chkbxQueryExpansion1.AutoSize = true;
            this.chkbxQueryExpansion1.Location = new System.Drawing.Point(700, 358);
            this.chkbxQueryExpansion1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkbxQueryExpansion1.Name = "chkbxQueryExpansion1";
            this.chkbxQueryExpansion1.Size = new System.Drawing.Size(149, 19);
            this.chkbxQueryExpansion1.TabIndex = 40;
            this.chkbxQueryExpansion1.Text = "Query expansion";
            this.chkbxQueryExpansion1.UseVisualStyleBackColor = true;
            this.chkbxQueryExpansion1.CheckedChanged += new System.EventHandler(this.ChkbxQueryExpansion1_CheckedChanged);
            // 
            // chkbxProcessing1
            // 
            this.chkbxProcessing1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.chkbxProcessing1.AutoSize = true;
            this.chkbxProcessing1.Location = new System.Drawing.Point(686, 325);
            this.chkbxProcessing1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkbxProcessing1.Name = "chkbxProcessing1";
            this.chkbxProcessing1.Size = new System.Drawing.Size(189, 19);
            this.chkbxProcessing1.TabIndex = 6;
            this.chkbxProcessing1.Text = "Do not process query";
            this.chkbxProcessing1.UseVisualStyleBackColor = true;
            this.chkbxProcessing1.CheckedChanged += new System.EventHandler(this.ChkbxProcessing1_CheckedChanged);
            // 
            // pnlSearch
            // 
            this.pnlSearch.Controls.Add(this.tabControl1);
            this.pnlSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSearch.Location = new System.Drawing.Point(0, 0);
            this.pnlSearch.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlSearch.Name = "pnlSearch";
            this.pnlSearch.Size = new System.Drawing.Size(1557, 678);
            this.pnlSearch.TabIndex = 41;
            this.pnlSearch.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabSearch);
            this.tabControl1.Controls.Add(this.tabDiagnostics);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1557, 678);
            this.tabControl1.TabIndex = 36;
            // 
            // tabSearch
            // 
            this.tabSearch.Controls.Add(this.pnlSearchHome);
            this.tabSearch.Controls.Add(this.pnlSearchResults);
            this.tabSearch.Location = new System.Drawing.Point(4, 25);
            this.tabSearch.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabSearch.Name = "tabSearch";
            this.tabSearch.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabSearch.Size = new System.Drawing.Size(1549, 649);
            this.tabSearch.TabIndex = 0;
            this.tabSearch.Text = "Search";
            this.tabSearch.UseVisualStyleBackColor = true;
            // 
            // pnlSearchResults
            // 
            this.pnlSearchResults.Controls.Add(this.cmbbxBoosting2);
            this.pnlSearchResults.Controls.Add(this.tblResults);
            this.pnlSearchResults.Controls.Add(this.txtFinalQuery);
            this.pnlSearchResults.Controls.Add(this.lblFinalQuery);
            this.pnlSearchResults.Controls.Add(lblSearch2);
            this.pnlSearchResults.Controls.Add(this.txtSearchContent2);
            this.pnlSearchResults.Controls.Add(this.btnSearch2);
            this.pnlSearchResults.Controls.Add(this.chkbxQueryExpansion2);
            this.pnlSearchResults.Controls.Add(this.chkbxProcessing2);
            this.pnlSearchResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlSearchResults.Location = new System.Drawing.Point(4, 3);
            this.pnlSearchResults.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlSearchResults.Name = "pnlSearchResults";
            this.pnlSearchResults.Size = new System.Drawing.Size(1541, 643);
            this.pnlSearchResults.TabIndex = 36;
            this.pnlSearchResults.Visible = false;
            // 
            // cmbbxBoosting2
            // 
            this.cmbbxBoosting2.FormattingEnabled = true;
            this.cmbbxBoosting2.Items.AddRange(new object[] {
            "No Boosting",
            "Title Boosting",
            "Query Boosting"});
            this.cmbbxBoosting2.Location = new System.Drawing.Point(16, 96);
            this.cmbbxBoosting2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cmbbxBoosting2.Name = "cmbbxBoosting2";
            this.cmbbxBoosting2.Size = new System.Drawing.Size(277, 23);
            this.cmbbxBoosting2.TabIndex = 39;
            this.cmbbxBoosting2.SelectedIndexChanged += new System.EventHandler(this.CmbbxBoosting2_SelectedIndexChanged);
            // 
            // tblResults
            // 
            this.tblResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tblResults.AutoScroll = true;
            this.tblResults.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tblResults.ColumnCount = 1;
            this.tblResults.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblResults.Location = new System.Drawing.Point(15, 134);
            this.tblResults.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tblResults.Name = "tblResults";
            this.tblResults.RowCount = 1;
            this.tblResults.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tblResults.Size = new System.Drawing.Size(1513, 490);
            this.tblResults.TabIndex = 38;
            // 
            // txtSearchContent2
            // 
            this.txtSearchContent2.Location = new System.Drawing.Point(15, 38);
            this.txtSearchContent2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtSearchContent2.Name = "txtSearchContent2";
            this.txtSearchContent2.Size = new System.Drawing.Size(504, 25);
            this.txtSearchContent2.TabIndex = 33;
            this.txtSearchContent2.TextChanged += new System.EventHandler(this.TxtSearchContent2_TextChanged);
            // 
            // btnSearch2
            // 
            this.btnSearch2.Enabled = false;
            this.btnSearch2.Location = new System.Drawing.Point(421, 72);
            this.btnSearch2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSearch2.Name = "btnSearch2";
            this.btnSearch2.Size = new System.Drawing.Size(100, 27);
            this.btnSearch2.TabIndex = 34;
            this.btnSearch2.Text = "Search";
            this.btnSearch2.UseVisualStyleBackColor = true;
            this.btnSearch2.Click += new System.EventHandler(this.BtnSearch_Click);
            // 
            // chkbxQueryExpansion2
            // 
            this.chkbxQueryExpansion2.AutoSize = true;
            this.chkbxQueryExpansion2.Location = new System.Drawing.Point(155, 68);
            this.chkbxQueryExpansion2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkbxQueryExpansion2.Name = "chkbxQueryExpansion2";
            this.chkbxQueryExpansion2.Size = new System.Drawing.Size(149, 19);
            this.chkbxQueryExpansion2.TabIndex = 35;
            this.chkbxQueryExpansion2.Text = "Query expansion";
            this.chkbxQueryExpansion2.UseVisualStyleBackColor = true;
            this.chkbxQueryExpansion2.CheckedChanged += new System.EventHandler(this.ChkbxQueryExpansion2_CheckedChanged);
            // 
            // chkbxProcessing2
            // 
            this.chkbxProcessing2.AutoSize = true;
            this.chkbxProcessing2.Location = new System.Drawing.Point(16, 68);
            this.chkbxProcessing2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chkbxProcessing2.Name = "chkbxProcessing2";
            this.chkbxProcessing2.Size = new System.Drawing.Size(141, 19);
            this.chkbxProcessing2.TabIndex = 35;
            this.chkbxProcessing2.Text = "Do not process";
            this.chkbxProcessing2.UseVisualStyleBackColor = true;
            this.chkbxProcessing2.CheckedChanged += new System.EventHandler(this.ChkbxProcessing2_CheckedChanged);
            // 
            // tabDiagnostics
            // 
            this.tabDiagnostics.Controls.Add(this.txtQueryResults);
            this.tabDiagnostics.Controls.Add(this.txtAllResults);
            this.tabDiagnostics.Controls.Add(this.btnSave);
            this.tabDiagnostics.Controls.Add(lblAllResults);
            this.tabDiagnostics.Controls.Add(lblQueryResults);
            this.tabDiagnostics.Controls.Add(this.lblQueryGenTimeResult);
            this.tabDiagnostics.Controls.Add(this.lblIndexTime);
            this.tabDiagnostics.Controls.Add(this.lblQueryGenTime);
            this.tabDiagnostics.Controls.Add(this.lblIndexTimeResult);
            this.tabDiagnostics.Controls.Add(this.lblSearchingTimes);
            this.tabDiagnostics.Controls.Add(this.lblNumRelDocsResult);
            this.tabDiagnostics.Controls.Add(this.lblNumRelDocs);
            this.tabDiagnostics.Controls.Add(this.lblSearchingTimesResult);
            this.tabDiagnostics.Location = new System.Drawing.Point(4, 25);
            this.tabDiagnostics.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabDiagnostics.Name = "tabDiagnostics";
            this.tabDiagnostics.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tabDiagnostics.Size = new System.Drawing.Size(1549, 649);
            this.tabDiagnostics.TabIndex = 1;
            this.tabDiagnostics.Text = "Diagnostics";
            this.tabDiagnostics.UseVisualStyleBackColor = true;
            // 
            // txtQueryResults
            // 
            this.txtQueryResults.Location = new System.Drawing.Point(27, 138);
            this.txtQueryResults.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtQueryResults.Name = "txtQueryResults";
            this.txtQueryResults.ReadOnly = true;
            this.txtQueryResults.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.txtQueryResults.Size = new System.Drawing.Size(731, 448);
            this.txtQueryResults.TabIndex = 29;
            this.txtQueryResults.Text = "";
            this.txtQueryResults.TextChanged += new System.EventHandler(this.TxtQueryResults_TextChanged);
            // 
            // txtAllResults
            // 
            this.txtAllResults.Location = new System.Drawing.Point(783, 138);
            this.txtAllResults.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtAllResults.Name = "txtAllResults";
            this.txtAllResults.ReadOnly = true;
            this.txtAllResults.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.txtAllResults.Size = new System.Drawing.Size(731, 448);
            this.txtAllResults.TabIndex = 29;
            this.txtAllResults.Text = "";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(1415, 600);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 27);
            this.btnSave.TabIndex = 28;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.BtnSave_Click);
            // 
            // imglstDropdown
            // 
            this.imglstDropdown.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imglstDropdown.ImageStream")));
            this.imglstDropdown.TransparentColor = System.Drawing.Color.Transparent;
            this.imglstDropdown.Images.SetKeyName(0, "expand-arrow-32.png");
            this.imglstDropdown.Images.SetKeyName(1, "collapse-arrow-32.png");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1557, 678);
            this.Controls.Add(this.pnlSearch);
            this.Controls.Add(this.pnlIndex);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.MinimumSize = new System.Drawing.Size(1061, 685);
            this.Name = "Form1";
            this.Text = "Search Engine";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlIndex.ResumeLayout(false);
            this.pnlIndex.PerformLayout();
            this.pnlSearchHome.ResumeLayout(false);
            this.pnlSearchHome.PerformLayout();
            this.pnlSearch.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabSearch.ResumeLayout(false);
            this.pnlSearchResults.ResumeLayout(false);
            this.pnlSearchResults.PerformLayout();
            this.tabDiagnostics.ResumeLayout(false);
            this.tabDiagnostics.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TextBox txtCollectionFile;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblCollectionFile;
        private System.Windows.Forms.TextBox txtIndexFile;
        private System.Windows.Forms.Button btnBrowse2;
        private System.Windows.Forms.Label lblIndexSave;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button btnCreateIndex;
        private System.Windows.Forms.TextBox txtSearchContent1;
        private System.Windows.Forms.Button btnSearch1;
        private System.Windows.Forms.Label lblQueryGenTimeResult;
        private System.Windows.Forms.Label lblIndexTime;
        private System.Windows.Forms.Label lblQueryGenTime;
        private System.Windows.Forms.Label lblSearchingTimesResult;
        private System.Windows.Forms.Label lblFinalQuery;
        private System.Windows.Forms.Label lblNumRelDocs;
        private System.Windows.Forms.Label lblNumRelDocsResult;
        private System.Windows.Forms.TextBox txtFinalQuery;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label lblSearchingTimes;
        private System.Windows.Forms.Label lblIndexTimeResult;
		private System.Windows.Forms.Panel pnlIndex;
		private System.Windows.Forms.Panel pnlSearchHome;
		private System.Windows.Forms.Panel pnlSearch;
		private System.Windows.Forms.CheckBox chkbxProcessing1;
		private System.Windows.Forms.TextBox txtSearchContent2;
		private System.Windows.Forms.Button btnSearch2;
		private System.Windows.Forms.CheckBox chkbxProcessing2;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabSearch;
		private System.Windows.Forms.TabPage tabDiagnostics;
		private System.Windows.Forms.Panel pnlSearchResults;
		private System.Windows.Forms.ImageList imglstDropdown;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.TableLayoutPanel tblResults;
		private System.Windows.Forms.RichTextBox txtQueryResults;
		private System.Windows.Forms.RichTextBox txtAllResults;
		private System.Windows.Forms.ComboBox cmbbxBoosting1;
		private System.Windows.Forms.CheckBox chkbxQueryExpansion1;
		private System.Windows.Forms.ComboBox cmbbxBoosting2;
		private System.Windows.Forms.CheckBox chkbxQueryExpansion2;
		private System.Windows.Forms.Label lblSuggestions1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
    }
}

