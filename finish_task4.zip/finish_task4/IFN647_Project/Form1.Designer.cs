﻿namespace IFN647_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtCollectionFile = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblCollectionFile = new System.Windows.Forms.Label();
            this.txtIndexFile = new System.Windows.Forms.TextBox();
            this.btnBrowse2 = new System.Windows.Forms.Button();
            this.lblIndexSave = new System.Windows.Forms.Label();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.btnCreateIndex = new System.Windows.Forms.Button();
            this.SearchContent = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Time = new System.Windows.Forms.Label();
            this.Without_Process = new System.Windows.Forms.RadioButton();
            this.Processing_choice = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Searching_time = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Number_result = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.save_button = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.coun_time = new System.Windows.Forms.Label();
            this.task4 = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Matching_text = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCollectionFile
            // 
            this.txtCollectionFile.Location = new System.Drawing.Point(10, 86);
            this.txtCollectionFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCollectionFile.Name = "txtCollectionFile";
            this.txtCollectionFile.ReadOnly = true;
            this.txtCollectionFile.Size = new System.Drawing.Size(241, 21);
            this.txtCollectionFile.TabIndex = 0;
            this.txtCollectionFile.TextChanged += new System.EventHandler(this.TxtCollectionFile_TextChanged);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(74, 110);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(82, 42);
            this.btnBrowse.TabIndex = 1;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.BtnBrowse_Click);
            // 
            // lblCollectionFile
            // 
            this.lblCollectionFile.AutoSize = true;
            this.lblCollectionFile.Location = new System.Drawing.Point(61, 71);
            this.lblCollectionFile.Name = "lblCollectionFile";
            this.lblCollectionFile.Size = new System.Drawing.Size(119, 12);
            this.lblCollectionFile.TabIndex = 2;
            this.lblCollectionFile.Text = "Collection Location";
            // 
            // txtIndexFile
            // 
            this.txtIndexFile.Location = new System.Drawing.Point(10, 202);
            this.txtIndexFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtIndexFile.Name = "txtIndexFile";
            this.txtIndexFile.ReadOnly = true;
            this.txtIndexFile.Size = new System.Drawing.Size(241, 21);
            this.txtIndexFile.TabIndex = 0;
            this.txtIndexFile.TextChanged += new System.EventHandler(this.TxtIndexFile_TextChanged);
            // 
            // btnBrowse2
            // 
            this.btnBrowse2.Location = new System.Drawing.Point(75, 237);
            this.btnBrowse2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBrowse2.Name = "btnBrowse2";
            this.btnBrowse2.Size = new System.Drawing.Size(81, 43);
            this.btnBrowse2.TabIndex = 1;
            this.btnBrowse2.Text = "Browse";
            this.btnBrowse2.UseVisualStyleBackColor = true;
            this.btnBrowse2.Click += new System.EventHandler(this.BtnBrowse2_Click);
            // 
            // lblIndexSave
            // 
            this.lblIndexSave.AutoSize = true;
            this.lblIndexSave.Location = new System.Drawing.Point(61, 188);
            this.lblIndexSave.Name = "lblIndexSave";
            this.lblIndexSave.Size = new System.Drawing.Size(119, 12);
            this.lblIndexSave.TabIndex = 2;
            this.lblIndexSave.Text = "Index Save Location";
            // 
            // btnCreateIndex
            // 
            this.btnCreateIndex.Enabled = false;
            this.btnCreateIndex.Location = new System.Drawing.Point(74, 303);
            this.btnCreateIndex.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCreateIndex.Name = "btnCreateIndex";
            this.btnCreateIndex.Size = new System.Drawing.Size(82, 44);
            this.btnCreateIndex.TabIndex = 1;
            this.btnCreateIndex.Text = "Create Index";
            this.btnCreateIndex.UseVisualStyleBackColor = true;
            this.btnCreateIndex.Click += new System.EventHandler(this.BtnCreateIndex_Click);
            // 
            // SearchContent
            // 
            this.SearchContent.Location = new System.Drawing.Point(10, 398);
            this.SearchContent.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SearchContent.Name = "SearchContent";
            this.SearchContent.Size = new System.Drawing.Size(241, 21);
            this.SearchContent.TabIndex = 3;
            this.SearchContent.TextChanged += new System.EventHandler(this.SearchContent_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 382);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "Input Search Content";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(17, 468);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 40);
            this.button1.TabIndex = 5;
            this.button1.Text = "Search";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Location = new System.Drawing.Point(496, 16);
            this.Time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(11, 12);
            this.Time.TabIndex = 6;
            this.Time.Text = "0";
            this.Time.Click += new System.EventHandler(this.Time_Click);
            // 
            // Without_Process
            // 
            this.Without_Process.AutoSize = true;
            this.Without_Process.Location = new System.Drawing.Point(75, 443);
            this.Without_Process.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Without_Process.Name = "Without_Process";
            this.Without_Process.Size = new System.Drawing.Size(113, 16);
            this.Without_Process.TabIndex = 7;
            this.Without_Process.TabStop = true;
            this.Without_Process.Text = "Without Process";
            this.Without_Process.UseVisualStyleBackColor = true;
            this.Without_Process.CheckedChanged += new System.EventHandler(this.Without_Process_CheckedChanged);
            // 
            // Processing_choice
            // 
            this.Processing_choice.AutoSize = true;
            this.Processing_choice.Location = new System.Drawing.Point(75, 423);
            this.Processing_choice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Processing_choice.Name = "Processing_choice";
            this.Processing_choice.Size = new System.Drawing.Size(83, 16);
            this.Processing_choice.TabIndex = 8;
            this.Processing_choice.TabStop = true;
            this.Processing_choice.Text = "Processing";
            this.Processing_choice.UseVisualStyleBackColor = true;
            this.Processing_choice.CheckedChanged += new System.EventHandler(this.Processing_choice_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(304, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 12);
            this.label2.TabIndex = 9;
            this.label2.Text = "Time for Indexing   ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(582, 16);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "Time for Searching   ";
            // 
            // Searching_time
            // 
            this.Searching_time.AutoSize = true;
            this.Searching_time.Location = new System.Drawing.Point(774, 16);
            this.Searching_time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Searching_time.Name = "Searching_time";
            this.Searching_time.Size = new System.Drawing.Size(11, 12);
            this.Searching_time.TabIndex = 11;
            this.Searching_time.Text = "0";
            this.Searching_time.Click += new System.EventHandler(this.Searching_time_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(431, 84);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "The final query";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(304, 49);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 12);
            this.label5.TabIndex = 14;
            this.label5.Text = "Number of relevant results";
            // 
            // Number_result
            // 
            this.Number_result.AutoSize = true;
            this.Number_result.Location = new System.Drawing.Point(496, 49);
            this.Number_result.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Number_result.Name = "Number_result";
            this.Number_result.Size = new System.Drawing.Size(11, 12);
            this.Number_result.TabIndex = 15;
            this.Number_result.Text = "0";
            this.Number_result.Click += new System.EventHandler(this.Number_result_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(289, 202);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(419, 176);
            this.richTextBox1.TabIndex = 18;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.RichTextBox1_TextChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(289, 110);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(419, 58);
            this.txtSearch.TabIndex = 20;
            this.txtSearch.TextChanged += new System.EventHandler(this.TxtSearch_TextChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(163, 468);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(88, 40);
            this.button4.TabIndex = 21;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // save_button
            // 
            this.save_button.Location = new System.Drawing.Point(1042, 695);
            this.save_button.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(115, 52);
            this.save_button.TabIndex = 22;
            this.save_button.Text = "save";
            this.save_button.UseVisualStyleBackColor = true;
            this.save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.SaveFileDialog1_FileOk);
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(738, 370);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(430, 311);
            this.richTextBox2.TabIndex = 23;
            this.richTextBox2.Text = "";
            this.richTextBox2.TextChanged += new System.EventHandler(this.RichTextBox2_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(582, 49);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 12);
            this.label6.TabIndex = 24;
            this.label6.Text = "Searching Times";
            // 
            // coun_time
            // 
            this.coun_time.AutoSize = true;
            this.coun_time.Location = new System.Drawing.Point(774, 49);
            this.coun_time.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.coun_time.Name = "coun_time";
            this.coun_time.Size = new System.Drawing.Size(11, 12);
            this.coun_time.TabIndex = 25;
            this.coun_time.Text = "0";
            this.coun_time.Click += new System.EventHandler(this.Coun_time_Click);
            // 
            // task4
            // 
            this.task4.Location = new System.Drawing.Point(738, 110);
            this.task4.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.task4.Name = "task4";
            this.task4.Size = new System.Drawing.Size(419, 195);
            this.task4.TabIndex = 26;
            this.task4.Text = "";
            this.task4.TextChanged += new System.EventHandler(this.Task4_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(864, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 12);
            this.label7.TabIndex = 27;
            this.label7.Text = "baseline_for_this_query";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(864, 321);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(137, 12);
            this.label8.TabIndex = 28;
            this.label8.Text = "baseline_for_all_query";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(431, 188);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 12);
            this.label9.TabIndex = 29;
            this.label9.Text = "Answer_For_Query";
            // 
            // Matching_text
            // 
            this.Matching_text.Location = new System.Drawing.Point(289, 423);
            this.Matching_text.Name = "Matching_text";
            this.Matching_text.Size = new System.Drawing.Size(430, 323);
            this.Matching_text.TabIndex = 30;
            this.Matching_text.Text = "";
            this.Matching_text.TextChanged += new System.EventHandler(this.Matching_text_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(431, 398);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 12);
            this.label10.TabIndex = 31;
            this.label10.Text = "All_matching_Text";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1168, 758);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Matching_text);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.task4);
            this.Controls.Add(this.coun_time);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.save_button);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.Number_result);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Searching_time);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Processing_choice);
            this.Controls.Add(this.Without_Process);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SearchContent);
            this.Controls.Add(this.lblIndexSave);
            this.Controls.Add(this.lblCollectionFile);
            this.Controls.Add(this.btnCreateIndex);
            this.Controls.Add(this.btnBrowse2);
            this.Controls.Add(this.txtIndexFile);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtCollectionFile);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "xxx";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TextBox txtCollectionFile;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblCollectionFile;
        private System.Windows.Forms.TextBox txtIndexFile;
        private System.Windows.Forms.Button btnBrowse2;
        private System.Windows.Forms.Label lblIndexSave;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button btnCreateIndex;
        private System.Windows.Forms.TextBox SearchContent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.RadioButton Without_Process;
        private System.Windows.Forms.RadioButton Processing_choice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Searching_time;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Number_result;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label coun_time;
        private System.Windows.Forms.RichTextBox task4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox Matching_text;
        private System.Windows.Forms.Label label10;
    }
}

