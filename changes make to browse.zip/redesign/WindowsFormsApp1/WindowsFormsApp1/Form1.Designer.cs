﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Browse = new System.Windows.Forms.Button();
            this.browse_text = new System.Windows.Forms.TextBox();
            this.save_button = new System.Windows.Forms.Button();
            this.save_text = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Browse
            // 
            this.Browse.Location = new System.Drawing.Point(313, 105);
            this.Browse.Name = "Browse";
            this.Browse.Size = new System.Drawing.Size(136, 69);
            this.Browse.TabIndex = 0;
            this.Browse.Text = "Browse";
            this.Browse.UseVisualStyleBackColor = true;
            this.Browse.Click += new System.EventHandler(this.Browse_Click);
            // 
            // browse_text
            // 
            this.browse_text.Location = new System.Drawing.Point(237, 57);
            this.browse_text.Name = "browse_text";
            this.browse_text.Size = new System.Drawing.Size(307, 25);
            this.browse_text.TabIndex = 1;
            this.browse_text.TextChanged += new System.EventHandler(this.Browse_text_TextChanged);
            // 
            // save_button
            // 
            this.save_button.Location = new System.Drawing.Point(313, 305);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(136, 79);
            this.save_button.TabIndex = 2;
            this.save_button.Text = "Save";
            this.save_button.UseVisualStyleBackColor = true;
            this.save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // save_text
            // 
            this.save_text.Location = new System.Drawing.Point(237, 254);
            this.save_text.Name = "save_text";
            this.save_text.Size = new System.Drawing.Size(307, 25);
            this.save_text.TabIndex = 3;
            this.save_text.TextChanged += new System.EventHandler(this.Save_text_TextChanged);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog1_FileOk);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(579, 114);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 60);
            this.button1.TabIndex = 4;
            this.button1.Text = "Testing collect data";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(875, 495);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.save_text);
            this.Controls.Add(this.save_button);
            this.Controls.Add(this.browse_text);
            this.Controls.Add(this.Browse);
            this.Name = "Form1";
            this.Text = "Browse";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Browse;
        private System.Windows.Forms.TextBox browse_text;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.TextBox save_text;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button1;
    }
}

