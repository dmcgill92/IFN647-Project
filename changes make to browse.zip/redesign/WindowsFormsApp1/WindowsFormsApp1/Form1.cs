﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Entry myentry = new Entry();
        
        Passage mypassage = new Passage();
        Overall_Collection overall_collection = new Overall_Collection();
        

        public Form1()
        {
            InitializeComponent();
        }

        private void Browse_Click(object sender, EventArgs e)
        {
            string new_is_selected = "";
            string new_url = "";
            string new_string = "";
            string new_passge_id = "";
            string new_string_id = "";
            string new_answer = "";
            string new_type = "";
            string new_query = "";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                var path = openFileDialog1.FileName;
                browse_text.Text = path;
            }
            string filePath =browse_text.Text;
            StreamReader streamReader = new StreamReader(filePath);
            JsonTextReader JTextreader = new JsonTextReader(streamReader);

            JTextreader.SupportMultipleContent = true;

            var serializer = new JsonSerializer();
            while (JTextreader.Read())
            {
                if (JTextreader.TokenType == JsonToken.StartObject)
                {
                    
                    myentry = serializer.Deserialize<Entry>(JTextreader);
                    
                    
                    for (int i = 0; i < myentry.passages.Count; i++)
                    {
                        new_is_selected = new_is_selected + myentry.passages[i].is_selected + "‰";
                        new_url = new_url + myentry.passages[i].url + "‰";
                        new_string= new_string + myentry.passages[i].passage_text + "‰";
                        new_passge_id= new_passge_id + myentry.passages[i].passage_id + "‰";
                    }
                    new_string_id = new_string_id + myentry.query_id + "‰";
                    new_answer= new_answer+String.Join(" ", myentry.answers.ToArray()) + "‰";
                    new_type = new_type + myentry.query_type + "‰";
                    new_query = new_query + myentry.query + "‰";
                }
            }
            List<string> result_id = new_string_id.Split('‰').ToList();
            List<string> result_url = new_url.Split('‰').ToList();
            List<string> result_selected = new_is_selected.Split('‰').ToList();
            List<string> result_passage_text = new_string.Split('‰').ToList();
            List<string> result_passage_id = new_passge_id.Split('‰').ToList();
            List<string> result_answer= new_answer.Split('‰').ToList();
            List<string> result_type = new_type.Split('‰').ToList();
            List<string> result_query = new_query.Split('‰').ToList();
            int data_len = result_passage_id.Count;
            Collection mycollection = new Collection(data_len);  //To define the length of the mycollection class

            for (int i = 0; i < result_passage_id.Count; i++)  //Collect the data 
            {
                mycollection.Selected[i] = result_selected[i];
                mycollection.Myurl[i] = result_url[i];
                mycollection.Mytext[i] = result_passage_text[i];
                mycollection.ID[i] = result_passage_id[i];
            }
            for (int i = 0; i < result_answer.Count; i++)
            {
                mycollection.Myanswer[i] = result_answer[i];
                mycollection.QueryID[i] = result_id[i];
                mycollection.QueryType[i] = result_type[i];
                mycollection.Query[i] = result_query[i];

            }

            //Collect the data for the whole class so that the data can be used in other method
            overall_collection.Selected = mycollection.Selected;
            overall_collection.Myurl = mycollection.Myurl;
            overall_collection.Mytext = mycollection.Mytext;
            overall_collection.ID = mycollection.ID;
            overall_collection.Myanswer = mycollection.Myanswer;
            overall_collection.QueryID = mycollection.QueryID;
            overall_collection.QueryType = mycollection.QueryType;
            overall_collection.Query = mycollection.Query;

        }





        private void Browse_text_TextChanged(object sender, EventArgs e)
        {

        }


        private void Save_button_Click(object sender, EventArgs e)
        {

        }

        private void Save_text_TextChanged(object sender, EventArgs e)
        {

        }

        private void OpenFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            foreach (var item in overall_collection.Myanswer)
            {
                Console.WriteLine(item);
            }
        }
    }
}
