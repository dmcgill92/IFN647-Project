﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Windows.Documents;

namespace IFN647_Project
{
    public partial class Form1 : Form
    {
        int count_query = 0;
        LuceneIndexer myLuceneApp = new LuceneIndexer();
        Passage mypassage = new Passage();
        TextAnalyser.TextAnalyser textAnalyser = new TextAnalyser.TextAnalyser();
       
        List<Entry> entries;
        private JSONParser jsonParser = new JSONParser();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Processing_choice.Checked = true;
            button1.Click += Button1_Click;
        }

        //Code for highlight color;
        public void hightlight_Color(string[] string_list, RichTextBox myrichbox)
        {
            foreach (string word in string_list)
            {
                int starIndex = 0;
                while (starIndex < myrichbox.TextLength)
                {
                    int wordStarIndex = myrichbox.Find(word, starIndex, RichTextBoxFinds.None);
                    if (wordStarIndex != -1)
                    {
                        myrichbox.SelectionStart = wordStarIndex;
                        myrichbox.SelectionLength = word.Length;
                        myrichbox.SelectionBackColor = Color.Yellow;
                    }
                    else
                        break;
                    starIndex += wordStarIndex + word.Length;
                }

            }
        }

        private void BtnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Json files (*.json)|*.json|Text files (*.txt)|*.txt";
            openFileDialog.Title = "Select collection file";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                var path = openFileDialog.FileName;
                txtCollectionFile.Text = path;
                entries = jsonParser.ReadJSON(path);
            }
        }

        private void BtnBrowse2_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.Description = "Select where to save index";
            if(folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                var path = folderBrowserDialog.SelectedPath;
                txtIndexFile.Text = path;

            }
        }

        private void TxtCollectionFile_TextChanged(object sender, EventArgs e)
        {
            btnCreateIndex.Enabled = !( String.IsNullOrEmpty(txtCollectionFile.Text) || String.IsNullOrEmpty(txtIndexFile.Text));
        }

        private void TxtIndexFile_TextChanged(object sender, EventArgs e)
        {
            btnCreateIndex.Enabled = !(String.IsNullOrEmpty(txtCollectionFile.Text) || String.IsNullOrEmpty(txtIndexFile.Text));
        }

        private void BtnCreateIndex_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();
            entries = jsonParser.ReadJSON(txtCollectionFile.Text);
            myLuceneApp.IndexCollection(txtIndexFile.Text + @"\Index", entries);
            stopwatch.Stop();

            Time.Text = stopwatch.Elapsed.TotalSeconds.ToString();
        }

        private void SearchContent_TextChanged(object sender, EventArgs e)
        {


        }
        
        private void Button1_Click(object sender, EventArgs e)
        {
            int data_len = 0;

            List<string> relevant_list = new List<string>();
            //Counting searching time
            
            //------------------------------------------
            string searchword = SearchContent.Text;
            if (searchword.Length!=0)
            {
                count_query++;
                if (Processing_choice.Checked == true)
                {

                    Stopwatch stopwatch = Stopwatch.StartNew();
                   
                    List<string> another_list =textAnalyser.StopWordFilter(textAnalyser.OutputTokens(searchword));
                    List<string> this_string_list = textAnalyser.OutputStems(textAnalyser.StopWordFilter(textAnalyser.OutputTokens(searchword)));
                    List<string> combine_list = this_string_list.Union(another_list).ToList();
                    string string_list = string.Join(" ", textAnalyser.OutputStems(textAnalyser.StopWordFilter(textAnalyser.OutputTokens(searchword))));
                    string final_combine_list = string.Join(" ", combine_list);



                    txtSearch.Text = string_list;
                    myLuceneApp.CreateSearcher();
                    myLuceneApp.CreateParser();
                    List<string> retrieval_data = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(final_combine_list));
                    Number_result.Text = (retrieval_data.Count).ToString();
                    if (coun_time != null)
                    {
                        coun_time.Text = count_query.ToString();
                    }

                    //Data categorize
                    data_len = retrieval_data.Count;
                    Collection mycollect = new Collection(data_len);
                    if (data_len != 0)
                    {
                        for (int i = 0; i < data_len; i++)
                        {
                            string[] sArray = retrieval_data[i].Split('‰');
                            mycollect.Rank[i] = sArray[1];
                            mycollect.Score[i] = sArray[2];
                            mycollect.ID[i] = sArray[3];
                            mycollect.Myurl[i] = sArray[4];
                            mycollect.Myanswer[i] = sArray[5];
                            mycollect.Mytext[i] = sArray[6];
                            mycollect.Selected[i] = sArray[7];
                            if (mycollect.Selected[i] == "1")
                            {
                                relevant_list.Add(mycollect.Mytext[i]);
                            }
                        }

                        //Task 4   Show baseline
                        for (int j = 0; j < count_query; j++)
                        {
                            for (int i = 0; i < data_len; i++)
                            {
                                mycollect.Myresult[i] = count_query.ToString("000") + "   " + "Q0" + "   " + mycollect.ID[i] + "   " + mycollect.Rank[i] + "   "
                                    + mycollect.Score[i] + "   " + "n10147675" + "\n";
                            }
                        }
                        task4.Text = string.Join("", mycollect.Myresult.ToArray());
                        


                        //Codes to get the sample answer
                        string relevant_string = string.Join(" ", relevant_list.ToArray());

                        richTextBox1.Text = "Query: " + searchword + "\n" + "Answer:" + mycollect.Myanswer[0]
                            + "\n" + "Relevant Passage:" + relevant_string;

                        string All_matching = string.Join(" ", mycollect.Mytext.ToArray());
                        Matching_text.Text = "All Matching Text: " + All_matching;


                        //---------------------------------------------
                        myLuceneApp.CleanUpSearch();
                        stopwatch.Stop();
                        Searching_time.Text = stopwatch.Elapsed.TotalSeconds.ToString();


                        //Codes to highlight words
                        string[] words = txtSearch.Text.Split(' ');
                        hightlight_Color(words, richTextBox1);
                        hightlight_Color(words, Matching_text);
                        richTextBox2.Text = richTextBox2.Text + task4.Text;
                    }

                }
                else if (Without_Process.Checked == true)
                {

                    Stopwatch stopwatch = Stopwatch.StartNew();
                    List<string> another_list = textAnalyser.OutputTokens(searchword);

                    string string_list = string.Join(" ", another_list);
                    txtSearch.Text = string_list;
                    myLuceneApp.CreateSearcher();
                    myLuceneApp.CreateParser();
                    List<string> retrieval_data = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(string_list));
                    Number_result.Text = (retrieval_data.Count).ToString();
                    if (coun_time != null)
                    {
                        coun_time.Text = count_query.ToString();
                    }
                    data_len = retrieval_data.Count;
                    Collection mycollect = new Collection(data_len);
                    if (data_len != 0)
                    {
                        for (int i = 0; i < data_len; i++)
                        {
                            string[] sArray = retrieval_data[i].Split('‰');
                            mycollect.Rank[i] = sArray[1];
                            mycollect.Score[i] = sArray[2];
                            mycollect.ID[i] = sArray[3];
                            mycollect.Myurl[i] = sArray[4];
                            mycollect.Myanswer[i] = sArray[5];
                            mycollect.Mytext[i] = sArray[6];
                            mycollect.Selected[i] = sArray[7];
                            if (mycollect.Selected[i] == "1")
                            {
                                relevant_list.Add(mycollect.Mytext[i]);
                            }
                        }

                        //Task 4   Show baseline

                        

                        for (int j = 0; j < count_query; j++)
                        {
                            for (int i = 0; i < data_len; i++)
                            {
                                mycollect.Myresult[i] = count_query.ToString("000") + "   " + "Q0" + "   " + mycollect.ID[i] + "   " + mycollect.Rank[i] + "   "
                                    + mycollect.Score[i] + "   " + "n10147675" + "\n";
                            }
                        }
                        task4.Text = string.Join("", mycollect.Myresult.ToArray());
                       


                        //Codes to get the sample answer
                        string relevant_string = string.Join(" ", relevant_list.ToArray());

                        richTextBox1.Text = "Query: " + searchword + "\n" + "Answer:" + mycollect.Myanswer[0]
                            + "\n" + "Relevant Passage:" + relevant_string;

                        string All_matching = string.Join(" ", mycollect.Mytext.ToArray());
                        Matching_text.Text = "All Matching Text: " + All_matching;


                        //---------------------------------------------
                        myLuceneApp.CleanUpSearch();
                        stopwatch.Stop();
                        Searching_time.Text = stopwatch.Elapsed.TotalSeconds.ToString();


                        //Codes to highlight words
                        string[] words = txtSearch.Text.Split(' ');
                        hightlight_Color(words, richTextBox1);
                        hightlight_Color(words, Matching_text);
                        richTextBox2.Text = richTextBox2.Text + task4.Text;
                    }


                }
            }


           
            
        }
        
        

        private void Time_Click(object sender, EventArgs e)
        {
            
        }

        private void Processing_choice_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Without_Process_CheckedChanged(object sender, EventArgs e)
        {
  
        }

        private void Searching_time_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Number_result_Click(object sender, EventArgs e)
        {
            
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            task4.Clear();
            txtSearch.Clear();
            richTextBox1.Clear();
            Matching_text.Clear();
            richTextBox2.Clear();
            coun_time.Text = "0";
            count_query=0 ;
        }

        private void Save_button_Click(object sender, EventArgs e)
        {
            DialogResult result = saveFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                string name = saveFileDialog1.FileName;
                File.WriteAllText(name, richTextBox2.Text);
            }
        }



        private void SaveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void RichTextBox2_TextChanged(object sender, EventArgs e)
        {


            



        }

        private void Coun_time_Click(object sender, EventArgs e)
        {
            
            
        }

        private void Task4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Matching_text_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
