﻿namespace IFN647_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtCollectionFile = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblCollectionFile = new System.Windows.Forms.Label();
            this.txtIndexFile = new System.Windows.Forms.TextBox();
            this.btnBrowse2 = new System.Windows.Forms.Button();
            this.lblIndexSave = new System.Windows.Forms.Label();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.btnCreateIndex = new System.Windows.Forms.Button();
            this.SearchContent = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Time = new System.Windows.Forms.Label();
            this.Without_Process = new System.Windows.Forms.RadioButton();
            this.Processing_choice = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Searching_time = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Number_result = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.save_button = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.coun_time = new System.Windows.Forms.Label();
            this.task4 = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Matching_text = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Save_cranqrel = new System.Windows.Forms.Button();
            this.savedialogconqrel = new System.Windows.Forms.SaveFileDialog();
            this.label11 = new System.Windows.Forms.Label();
            this.save_conqrel = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.Link = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCollectionFile
            // 
            this.txtCollectionFile.Location = new System.Drawing.Point(13, 108);
            this.txtCollectionFile.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtCollectionFile.Name = "txtCollectionFile";
            this.txtCollectionFile.ReadOnly = true;
            this.txtCollectionFile.Size = new System.Drawing.Size(320, 25);
            this.txtCollectionFile.TabIndex = 0;
            this.txtCollectionFile.TextChanged += new System.EventHandler(this.TxtCollectionFile_TextChanged);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(99, 138);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(109, 52);
            this.btnBrowse.TabIndex = 1;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.BtnBrowse_Click);
            // 
            // lblCollectionFile
            // 
            this.lblCollectionFile.AutoSize = true;
            this.lblCollectionFile.Location = new System.Drawing.Point(81, 89);
            this.lblCollectionFile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCollectionFile.Name = "lblCollectionFile";
            this.lblCollectionFile.Size = new System.Drawing.Size(159, 15);
            this.lblCollectionFile.TabIndex = 2;
            this.lblCollectionFile.Text = "Collection Location";
            // 
            // txtIndexFile
            // 
            this.txtIndexFile.Location = new System.Drawing.Point(13, 252);
            this.txtIndexFile.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.txtIndexFile.Name = "txtIndexFile";
            this.txtIndexFile.ReadOnly = true;
            this.txtIndexFile.Size = new System.Drawing.Size(320, 25);
            this.txtIndexFile.TabIndex = 0;
            this.txtIndexFile.TextChanged += new System.EventHandler(this.TxtIndexFile_TextChanged);
            // 
            // btnBrowse2
            // 
            this.btnBrowse2.Location = new System.Drawing.Point(100, 296);
            this.btnBrowse2.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnBrowse2.Name = "btnBrowse2";
            this.btnBrowse2.Size = new System.Drawing.Size(108, 54);
            this.btnBrowse2.TabIndex = 1;
            this.btnBrowse2.Text = "Browse";
            this.btnBrowse2.UseVisualStyleBackColor = true;
            this.btnBrowse2.Click += new System.EventHandler(this.BtnBrowse2_Click);
            // 
            // lblIndexSave
            // 
            this.lblIndexSave.AutoSize = true;
            this.lblIndexSave.Location = new System.Drawing.Point(81, 235);
            this.lblIndexSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndexSave.Name = "lblIndexSave";
            this.lblIndexSave.Size = new System.Drawing.Size(159, 15);
            this.lblIndexSave.TabIndex = 2;
            this.lblIndexSave.Text = "Index Save Location";
            // 
            // btnCreateIndex
            // 
            this.btnCreateIndex.Enabled = false;
            this.btnCreateIndex.Location = new System.Drawing.Point(99, 379);
            this.btnCreateIndex.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.btnCreateIndex.Name = "btnCreateIndex";
            this.btnCreateIndex.Size = new System.Drawing.Size(109, 55);
            this.btnCreateIndex.TabIndex = 1;
            this.btnCreateIndex.Text = "Create Index";
            this.btnCreateIndex.UseVisualStyleBackColor = true;
            this.btnCreateIndex.Click += new System.EventHandler(this.BtnCreateIndex_Click);
            // 
            // SearchContent
            // 
            this.SearchContent.Location = new System.Drawing.Point(13, 498);
            this.SearchContent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SearchContent.Name = "SearchContent";
            this.SearchContent.Size = new System.Drawing.Size(320, 25);
            this.SearchContent.TabIndex = 3;
            this.SearchContent.TextChanged += new System.EventHandler(this.SearchContent_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 478);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Input Search Content";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 585);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 50);
            this.button1.TabIndex = 5;
            this.button1.Text = "Search";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Location = new System.Drawing.Point(661, 20);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(15, 15);
            this.Time.TabIndex = 6;
            this.Time.Text = "0";
            this.Time.Click += new System.EventHandler(this.Time_Click);
            // 
            // Without_Process
            // 
            this.Without_Process.AutoSize = true;
            this.Without_Process.Location = new System.Drawing.Point(100, 554);
            this.Without_Process.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Without_Process.Name = "Without_Process";
            this.Without_Process.Size = new System.Drawing.Size(148, 19);
            this.Without_Process.TabIndex = 7;
            this.Without_Process.TabStop = true;
            this.Without_Process.Text = "Without Process";
            this.Without_Process.UseVisualStyleBackColor = true;
            this.Without_Process.CheckedChanged += new System.EventHandler(this.Without_Process_CheckedChanged);
            // 
            // Processing_choice
            // 
            this.Processing_choice.AutoSize = true;
            this.Processing_choice.Location = new System.Drawing.Point(100, 529);
            this.Processing_choice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Processing_choice.Name = "Processing_choice";
            this.Processing_choice.Size = new System.Drawing.Size(108, 19);
            this.Processing_choice.TabIndex = 8;
            this.Processing_choice.TabStop = true;
            this.Processing_choice.Text = "Processing";
            this.Processing_choice.UseVisualStyleBackColor = true;
            this.Processing_choice.CheckedChanged += new System.EventHandler(this.Processing_choice_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(405, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Time for Indexing   ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(776, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Time for Searching   ";
            // 
            // Searching_time
            // 
            this.Searching_time.AutoSize = true;
            this.Searching_time.Location = new System.Drawing.Point(1032, 20);
            this.Searching_time.Name = "Searching_time";
            this.Searching_time.Size = new System.Drawing.Size(15, 15);
            this.Searching_time.TabIndex = 11;
            this.Searching_time.Text = "0";
            this.Searching_time.Click += new System.EventHandler(this.Searching_time_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(575, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "The final query";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(405, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(215, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Number of relevant results";
            // 
            // Number_result
            // 
            this.Number_result.AutoSize = true;
            this.Number_result.Location = new System.Drawing.Point(661, 61);
            this.Number_result.Name = "Number_result";
            this.Number_result.Size = new System.Drawing.Size(15, 15);
            this.Number_result.TabIndex = 15;
            this.Number_result.Text = "0";
            this.Number_result.Click += new System.EventHandler(this.Number_result_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(385, 252);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(572, 219);
            this.richTextBox1.TabIndex = 18;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.RichTextBox1_TextChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(385, 138);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(557, 72);
            this.txtSearch.TabIndex = 20;
            this.txtSearch.TextChanged += new System.EventHandler(this.TxtSearch_TextChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(217, 585);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(117, 50);
            this.button4.TabIndex = 21;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // save_button
            // 
            this.save_button.Location = new System.Drawing.Point(1388, 867);
            this.save_button.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(153, 65);
            this.save_button.TabIndex = 22;
            this.save_button.Text = "save";
            this.save_button.UseVisualStyleBackColor = true;
            this.save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.SaveFileDialog1_FileOk);
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(980, 342);
            this.richTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ShortcutsEnabled = false;
            this.richTextBox2.Size = new System.Drawing.Size(561, 206);
            this.richTextBox2.TabIndex = 23;
            this.richTextBox2.Text = "";
            this.richTextBox2.TextChanged += new System.EventHandler(this.RichTextBox2_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(776, 61);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 15);
            this.label6.TabIndex = 24;
            this.label6.Text = "Searching Times";
            // 
            // coun_time
            // 
            this.coun_time.AutoSize = true;
            this.coun_time.Location = new System.Drawing.Point(1032, 61);
            this.coun_time.Name = "coun_time";
            this.coun_time.Size = new System.Drawing.Size(15, 15);
            this.coun_time.TabIndex = 25;
            this.coun_time.Text = "0";
            this.coun_time.Click += new System.EventHandler(this.Coun_time_Click);
            // 
            // task4
            // 
            this.task4.Location = new System.Drawing.Point(984, 138);
            this.task4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.task4.Name = "task4";
            this.task4.Size = new System.Drawing.Size(557, 139);
            this.task4.TabIndex = 26;
            this.task4.Text = "";
            this.task4.TextChanged += new System.EventHandler(this.Task4_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1152, 105);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(191, 15);
            this.label7.TabIndex = 27;
            this.label7.Text = "baseline_for_this_query";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1152, 316);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(183, 15);
            this.label8.TabIndex = 28;
            this.label8.Text = "baseline_for_all_query";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(575, 235);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 15);
            this.label9.TabIndex = 29;
            this.label9.Text = "Answer_For_Query";
            // 
            // Matching_text
            // 
            this.Matching_text.Location = new System.Drawing.Point(385, 529);
            this.Matching_text.Margin = new System.Windows.Forms.Padding(4);
            this.Matching_text.Name = "Matching_text";
            this.Matching_text.Size = new System.Drawing.Size(572, 403);
            this.Matching_text.TabIndex = 30;
            this.Matching_text.Text = "";
            this.Matching_text.TextChanged += new System.EventHandler(this.Matching_text_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(575, 498);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(143, 15);
            this.label10.TabIndex = 31;
            this.label10.Text = "All_matching_Text";
            // 
            // Save_cranqrel
            // 
            this.Save_cranqrel.Location = new System.Drawing.Point(1181, 867);
            this.Save_cranqrel.Name = "Save_cranqrel";
            this.Save_cranqrel.Size = new System.Drawing.Size(145, 65);
            this.Save_cranqrel.TabIndex = 34;
            this.Save_cranqrel.Text = "Save_cranqrel";
            this.Save_cranqrel.UseVisualStyleBackColor = true;
            this.Save_cranqrel.Click += new System.EventHandler(this.Save_cranqrel_Click);
            // 
            // savedialogconqrel
            // 
            this.savedialogconqrel.FileOk += new System.ComponentModel.CancelEventHandler(this.Savedialogconqrel_FileOk);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1214, 571);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 15);
            this.label11.TabIndex = 35;
            this.label11.Text = "cranqrel";
            // 
            // save_conqrel
            // 
            this.save_conqrel.Location = new System.Drawing.Point(984, 693);
            this.save_conqrel.Name = "save_conqrel";
            this.save_conqrel.Size = new System.Drawing.Size(557, 157);
            this.save_conqrel.TabIndex = 36;
            this.save_conqrel.Text = "";
            this.save_conqrel.TextChanged += new System.EventHandler(this.Save_conqrel_TextChanged);
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(980, 589);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(561, 86);
            this.richTextBox3.TabIndex = 37;
            this.richTextBox3.Text = "";
            this.richTextBox3.TextChanged += new System.EventHandler(this.RichTextBox3_TextChanged_1);
            // 
            // Link
            // 
            this.Link.Location = new System.Drawing.Point(23, 703);
            this.Link.Name = "Link";
            this.Link.Size = new System.Drawing.Size(127, 76);
            this.Link.TabIndex = 38;
            this.Link.Text = "button2";
            this.Link.UseVisualStyleBackColor = true;
            this.Link.Click += new System.EventHandler(this.Link_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1557, 948);
            this.Controls.Add(this.Link);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.save_conqrel);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.Save_cranqrel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.Matching_text);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.task4);
            this.Controls.Add(this.coun_time);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.save_button);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.Number_result);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Searching_time);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Processing_choice);
            this.Controls.Add(this.Without_Process);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SearchContent);
            this.Controls.Add(this.lblIndexSave);
            this.Controls.Add(this.lblCollectionFile);
            this.Controls.Add(this.btnCreateIndex);
            this.Controls.Add(this.btnBrowse2);
            this.Controls.Add(this.txtIndexFile);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtCollectionFile);
            this.Margin = new System.Windows.Forms.Padding(4, 2, 4, 2);
            this.Name = "Form1";
            this.Text = "xxx";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TextBox txtCollectionFile;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblCollectionFile;
        private System.Windows.Forms.TextBox txtIndexFile;
        private System.Windows.Forms.Button btnBrowse2;
        private System.Windows.Forms.Label lblIndexSave;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button btnCreateIndex;
        private System.Windows.Forms.TextBox SearchContent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.RadioButton Without_Process;
        private System.Windows.Forms.RadioButton Processing_choice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Searching_time;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Number_result;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label coun_time;
        private System.Windows.Forms.RichTextBox task4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox Matching_text;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button Save_cranqrel;
        private System.Windows.Forms.SaveFileDialog savedialogconqrel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RichTextBox save_conqrel;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Button Link;
    }
}

