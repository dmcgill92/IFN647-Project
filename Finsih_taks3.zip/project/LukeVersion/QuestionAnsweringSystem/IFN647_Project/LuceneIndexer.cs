﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net.Analysis; // for Analyser
using Lucene.Net.Documents; // for Document and Field
using Lucene.Net.Index; //for Index Writer
using Lucene.Net.Store; //for Directory
using Lucene.Net.Search; // for IndexSearcher
using Lucene.Net.QueryParsers;  // for QueryParser

namespace IFN647_Project
{
    class LuceneIndexer
    {
        Lucene.Net.Store.Directory luceneIndexDirectory;
        Lucene.Net.Analysis.Analyzer analyzer;
        Lucene.Net.Index.IndexWriter writer;
        Lucene.Net.Search.IndexSearcher searcher;
        Lucene.Net.QueryParsers.QueryParser parser;

        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TEXT_FN = "Text";

        public LuceneIndexer ()
        {
            luceneIndexDirectory = null;
            writer = null;
            analyzer = new Lucene.Net.Analysis.SimpleAnalyzer();
        }

        public void OpenIndex(string indexPath)
        {
            /* Make sure to pass a new directory that does not exist */
            luceneIndexDirectory = FSDirectory.Open(indexPath);
        }

        public void CreateAnalyser()
        {
            // TODO: Enter code to create the Lucene Analyser 
            analyzer = new SimpleAnalyzer();
        }

        public void CreateWriter()
        {
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            // TODO: Enter code to create the Lucene Writer 
            writer = new IndexWriter(luceneIndexDirectory, analyzer, true, mfl);

        }

        public void AddToIndex(Entry entry)
        {
            foreach (string item in entry.answers)
            {
                foreach (Passage passage in entry.passages)
                {
                    Field field = new Field(TEXT_FN,  "\nDocument ID:   " + passage.passage_id + "\nurl:   " + passage.url + "\nAnswers:    " + item +
                    "\npassage text:   " + passage.passage_text + "*************************************************************************************" + "\n" + "\n",
                    Field.Store.YES, Field.Index.ANALYZED_NO_NORMS, Field.TermVector.NO);

                    Document document = new Document();
                    document.Add(field);
                    writer.AddDocument(document);
                }
            }
            
            

        }

        public void IndexCollection(string filePath, List<Entry> collection)
        {
            OpenIndex(filePath);
            CreateAnalyser();
            CreateWriter();
            foreach(Entry entry in collection)
            {
                AddToIndex(entry);
            }
            CleanUp();
        }

        public void CleanUp()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }


        public void CreateSearcher()
        {
            searcher = new IndexSearcher(luceneIndexDirectory);
        }


        public void CreateParser()
        {
            parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TEXT_FN, analyzer);
        }


        public void CleanUpSearch()
        {
            searcher.Dispose();
        }


        public TopDocs SearchIndex(string querytext)
        { 

            //System.Console.WriteLine("Searching for " + querytext);
            querytext = querytext.ToLower();
            Query query = parser.Parse(querytext);
            TopDocs results = searcher.Search(query, 20);
            //System.Console.WriteLine("Number of results is " + results.TotalHits);
            return results;

        }


        public List<string> DisplayResults(TopDocs results)
        {
            int rank = 0;

            List<string> overall_retrieval_data = new List<string>();
            foreach (ScoreDoc scoreDoc in results.ScoreDocs)
            {
                rank++;
                // retrieve the document from the 'ScoreDoc' object
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);
                string myFieldValue = doc.Get(TEXT_FN).ToString();
                //Consoverall_retrieval_dataole.WriteLine("Rank " + rank + " score " + scoreDoc.Score + " text " + myFieldValue);
                //Console.WriteLine("Rank " + rank + "\n"+ myFieldValue);

                overall_retrieval_data.Add("\nrank:"+rank.ToString());
                overall_retrieval_data.Add(myFieldValue);


            }
                            

            foreach (string item in overall_retrieval_data)
            {
                Console.WriteLine(item);
            }


            return overall_retrieval_data;
        }
        





    }
}
