﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IFN647_Project
{
    public partial class Form1 : Form
    {

        LuceneIndexer myLuceneApp = new LuceneIndexer();
        Passage mypassage = new Passage();
        TextAnalyser.TextAnalyser textAnalyser = new TextAnalyser.TextAnalyser();
        public static System.Drawing.Color Highlight { get; }

        List<Entry> entries;
        private JSONParser jsonParser = new JSONParser();
        public System.Drawing.Color SelectionColor { get; set; }
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Processing_choice.Checked = true;
            Without_Process.Checked = true;
        }

        private void BtnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Json files (*.json)|*.json|Text files (*.txt)|*.txt";
            openFileDialog.Title = "Select collection file";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                var path = openFileDialog.FileName;
                txtCollectionFile.Text = path;
                entries = jsonParser.ReadJSON(path);
            }
        }

        private void BtnBrowse2_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.Description = "Select where to save index";
            if(folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                var path = folderBrowserDialog.SelectedPath;
                txtIndexFile.Text = path;

            }
        }

        private void TxtCollectionFile_TextChanged(object sender, EventArgs e)
        {
            btnCreateIndex.Enabled = !( String.IsNullOrEmpty(txtCollectionFile.Text) || String.IsNullOrEmpty(txtIndexFile.Text));
        }

        private void TxtIndexFile_TextChanged(object sender, EventArgs e)
        {
            btnCreateIndex.Enabled = !(String.IsNullOrEmpty(txtCollectionFile.Text) || String.IsNullOrEmpty(txtIndexFile.Text));
        }

        private void BtnCreateIndex_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();
            entries = jsonParser.ReadJSON(txtCollectionFile.Text);
            myLuceneApp.IndexCollection(txtIndexFile.Text + @"\Index", entries);
            stopwatch.Stop();

            Time.Text = stopwatch.Elapsed.TotalSeconds.ToString();
        }

        private void SearchContent_TextChanged(object sender, EventArgs e)
        {


        }
        
        private void Button1_Click(object sender, EventArgs e)
        {
            string searchword = SearchContent.Text;
            if (Processing_choice.Checked == true)
            {
                Stopwatch stopwatch = Stopwatch.StartNew();
                string string_list = string.Join(" ", textAnalyser.OutputStems(textAnalyser.StopWordFilter(textAnalyser.OutputTokens(searchword))));
                txtSearch.Text = string_list;
                myLuceneApp.CreateSearcher();
                myLuceneApp.CreateParser();
                List<string> retrieval_data = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(string_list));
                Number_result.Text = (retrieval_data.Count/2).ToString();
                richTextBox1.Text = string.Join(" ", retrieval_data.ToArray());

                myLuceneApp.CleanUpSearch();
                stopwatch.Stop();
                Searching_time.Text = stopwatch.Elapsed.TotalSeconds.ToString();

                string[] words = txtSearch.Text.Split(' ');

                foreach (string word in words)
                {
                    int starIndex = 0;
                    while (starIndex < richTextBox1.TextLength)
                    {
                        int wordStarIndex = richTextBox1.Find(word, starIndex, RichTextBoxFinds.None);
                        if (wordStarIndex != -1)
                        {
                            richTextBox1.SelectionStart = wordStarIndex;
                            richTextBox1.SelectionLength = word.Length;
                            richTextBox1.SelectionBackColor = Color.Yellow;
                        }
                        else
                            break;
                        starIndex += wordStarIndex + word.Length;
                    }

                }

            }

            else if(Without_Process.Checked == true)
            {
                Stopwatch stopwatch = Stopwatch.StartNew();
                myLuceneApp.CreateSearcher();
                myLuceneApp.CreateParser();
                List<string> retrieval_data = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(searchword));
                Number_result.Text = (retrieval_data.Count/2).ToString();
                richTextBox1.Text = string.Join(" ", retrieval_data.ToArray());
                myLuceneApp.CleanUpSearch();
                stopwatch.Stop();
                Searching_time.Text = stopwatch.Elapsed.TotalSeconds.ToString();
                txtSearch.Text = searchword;
                string[] words = txtSearch.Text.Split(' ');

                foreach (string word in words)
                {
                    int starIndex = 0;
                    while (starIndex < richTextBox1.TextLength)
                    {
                        int wordStarIndex = richTextBox1.Find(word, starIndex, RichTextBoxFinds.None);
                        if (wordStarIndex != -1)
                        {
                            richTextBox1.SelectionStart = wordStarIndex;
                            richTextBox1.SelectionLength = word.Length;
                            richTextBox1.SelectionBackColor = Color.Yellow;
                        }
                        else
                            break;
                        starIndex += wordStarIndex + word.Length;
                    }

                }

            }
        }

        private void Time_Click(object sender, EventArgs e)
        {
            
        }

        private void Processing_choice_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Without_Process_CheckedChanged(object sender, EventArgs e)
        {
  
        }

        private void Searching_time_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Number_result_Click(object sender, EventArgs e)
        {
            
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            
        }

        private void TxtSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            //richTextBox1.SelectionStart = 0;
            //richTextBox1.SelectAll();
            //richTextBox1.SelectionBackColor = Color.White;
            richTextBox1.Clear();
        }
    }
}
