﻿namespace IFN647_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtCollectionFile = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblCollectionFile = new System.Windows.Forms.Label();
            this.txtIndexFile = new System.Windows.Forms.TextBox();
            this.btnBrowse2 = new System.Windows.Forms.Button();
            this.lblIndexSave = new System.Windows.Forms.Label();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.btnCreateIndex = new System.Windows.Forms.Button();
            this.SearchContent = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Time = new System.Windows.Forms.Label();
            this.Without_Process = new System.Windows.Forms.RadioButton();
            this.Processing_choice = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Searching_time = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Number_result = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtCollectionFile
            // 
            this.txtCollectionFile.Location = new System.Drawing.Point(13, 107);
            this.txtCollectionFile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCollectionFile.Name = "txtCollectionFile";
            this.txtCollectionFile.ReadOnly = true;
            this.txtCollectionFile.Size = new System.Drawing.Size(320, 25);
            this.txtCollectionFile.TabIndex = 0;
            this.txtCollectionFile.TextChanged += new System.EventHandler(this.TxtCollectionFile_TextChanged);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(99, 138);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(109, 52);
            this.btnBrowse.TabIndex = 1;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.BtnBrowse_Click);
            // 
            // lblCollectionFile
            // 
            this.lblCollectionFile.AutoSize = true;
            this.lblCollectionFile.Location = new System.Drawing.Point(81, 89);
            this.lblCollectionFile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCollectionFile.Name = "lblCollectionFile";
            this.lblCollectionFile.Size = new System.Drawing.Size(159, 15);
            this.lblCollectionFile.TabIndex = 2;
            this.lblCollectionFile.Text = "Collection Location";
            // 
            // txtIndexFile
            // 
            this.txtIndexFile.Location = new System.Drawing.Point(13, 253);
            this.txtIndexFile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIndexFile.Name = "txtIndexFile";
            this.txtIndexFile.ReadOnly = true;
            this.txtIndexFile.Size = new System.Drawing.Size(320, 25);
            this.txtIndexFile.TabIndex = 0;
            this.txtIndexFile.TextChanged += new System.EventHandler(this.TxtIndexFile_TextChanged);
            // 
            // btnBrowse2
            // 
            this.btnBrowse2.Location = new System.Drawing.Point(100, 296);
            this.btnBrowse2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBrowse2.Name = "btnBrowse2";
            this.btnBrowse2.Size = new System.Drawing.Size(108, 54);
            this.btnBrowse2.TabIndex = 1;
            this.btnBrowse2.Text = "Browse";
            this.btnBrowse2.UseVisualStyleBackColor = true;
            this.btnBrowse2.Click += new System.EventHandler(this.BtnBrowse2_Click);
            // 
            // lblIndexSave
            // 
            this.lblIndexSave.AutoSize = true;
            this.lblIndexSave.Location = new System.Drawing.Point(81, 235);
            this.lblIndexSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndexSave.Name = "lblIndexSave";
            this.lblIndexSave.Size = new System.Drawing.Size(159, 15);
            this.lblIndexSave.TabIndex = 2;
            this.lblIndexSave.Text = "Index Save Location";
            // 
            // btnCreateIndex
            // 
            this.btnCreateIndex.Enabled = false;
            this.btnCreateIndex.Location = new System.Drawing.Point(99, 379);
            this.btnCreateIndex.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCreateIndex.Name = "btnCreateIndex";
            this.btnCreateIndex.Size = new System.Drawing.Size(109, 55);
            this.btnCreateIndex.TabIndex = 1;
            this.btnCreateIndex.Text = "Create Index";
            this.btnCreateIndex.UseVisualStyleBackColor = true;
            this.btnCreateIndex.Click += new System.EventHandler(this.BtnCreateIndex_Click);
            // 
            // SearchContent
            // 
            this.SearchContent.Location = new System.Drawing.Point(14, 498);
            this.SearchContent.Name = "SearchContent";
            this.SearchContent.Size = new System.Drawing.Size(320, 25);
            this.SearchContent.TabIndex = 3;
            this.SearchContent.TextChanged += new System.EventHandler(this.SearchContent_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 478);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Input Search Content";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(23, 585);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 50);
            this.button1.TabIndex = 5;
            this.button1.Text = "Search";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Location = new System.Drawing.Point(662, 20);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(15, 15);
            this.Time.TabIndex = 6;
            this.Time.Text = "0";
            this.Time.Click += new System.EventHandler(this.Time_Click);
            // 
            // Without_Process
            // 
            this.Without_Process.AutoSize = true;
            this.Without_Process.Location = new System.Drawing.Point(100, 554);
            this.Without_Process.Name = "Without_Process";
            this.Without_Process.Size = new System.Drawing.Size(148, 19);
            this.Without_Process.TabIndex = 7;
            this.Without_Process.TabStop = true;
            this.Without_Process.Text = "Without Process";
            this.Without_Process.UseVisualStyleBackColor = true;
            this.Without_Process.CheckedChanged += new System.EventHandler(this.Without_Process_CheckedChanged);
            // 
            // Processing_choice
            // 
            this.Processing_choice.AutoSize = true;
            this.Processing_choice.Location = new System.Drawing.Point(100, 529);
            this.Processing_choice.Name = "Processing_choice";
            this.Processing_choice.Size = new System.Drawing.Size(108, 19);
            this.Processing_choice.TabIndex = 8;
            this.Processing_choice.TabStop = true;
            this.Processing_choice.Text = "Processing";
            this.Processing_choice.UseVisualStyleBackColor = true;
            this.Processing_choice.CheckedChanged += new System.EventHandler(this.Processing_choice_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(405, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Time for Indexing   ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(776, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Time for Searching   ";
            // 
            // Searching_time
            // 
            this.Searching_time.AutoSize = true;
            this.Searching_time.Location = new System.Drawing.Point(1070, 20);
            this.Searching_time.Name = "Searching_time";
            this.Searching_time.Size = new System.Drawing.Size(15, 15);
            this.Searching_time.TabIndex = 11;
            this.Searching_time.Text = "0";
            this.Searching_time.Click += new System.EventHandler(this.Searching_time_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(776, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "The final query";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(405, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(215, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Number of relevant results";
            // 
            // Number_result
            // 
            this.Number_result.AutoSize = true;
            this.Number_result.Location = new System.Drawing.Point(662, 61);
            this.Number_result.Name = "Number_result";
            this.Number_result.Size = new System.Drawing.Size(15, 15);
            this.Number_result.TabIndex = 15;
            this.Number_result.Text = "0";
            this.Number_result.Click += new System.EventHandler(this.Number_result_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1180, 681);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 50);
            this.button2.TabIndex = 17;
            this.button2.Text = "save";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(408, 107);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(882, 568);
            this.richTextBox1.TabIndex = 18;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.RichTextBox1_TextChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(981, 58);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(192, 25);
            this.txtSearch.TabIndex = 20;
            this.txtSearch.TextChanged += new System.EventHandler(this.TxtSearch_TextChanged);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(217, 585);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(117, 50);
            this.button4.TabIndex = 21;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1330, 743);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Number_result);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Searching_time);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Processing_choice);
            this.Controls.Add(this.Without_Process);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SearchContent);
            this.Controls.Add(this.lblIndexSave);
            this.Controls.Add(this.lblCollectionFile);
            this.Controls.Add(this.btnCreateIndex);
            this.Controls.Add(this.btnBrowse2);
            this.Controls.Add(this.txtIndexFile);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtCollectionFile);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "xxx";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TextBox txtCollectionFile;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblCollectionFile;
        private System.Windows.Forms.TextBox txtIndexFile;
        private System.Windows.Forms.Button btnBrowse2;
        private System.Windows.Forms.Label lblIndexSave;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button btnCreateIndex;
        private System.Windows.Forms.TextBox SearchContent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.RadioButton Without_Process;
        private System.Windows.Forms.RadioButton Processing_choice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Searching_time;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Number_result;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button button4;
    }
}

