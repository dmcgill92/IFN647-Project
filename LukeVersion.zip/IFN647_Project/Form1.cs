﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IFN647_Project
{
    public partial class Form1 : Form
    {

        LuceneIndexer myLuceneApp = new LuceneIndexer();
        Passage mypassage = new Passage();
        TextAnalyser.TextAnalyser textAnalyser = new TextAnalyser.TextAnalyser();


        List<Entry> entries;
        private JSONParser jsonParser = new JSONParser();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Processing_choice.Checked = true;
            Without_Process.Checked = true;
        }

        private void BtnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "Json files (*.json)|*.json|Text files (*.txt)|*.txt";
            openFileDialog.Title = "Select collection file";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                var path = openFileDialog.FileName;
                txtCollectionFile.Text = path;
                entries = jsonParser.ReadJSON(path);
            }
        }

        private void BtnBrowse2_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.Description = "Select where to save index";
            if(folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                var path = folderBrowserDialog.SelectedPath;
                txtIndexFile.Text = path;

            }
        }

        private void TxtCollectionFile_TextChanged(object sender, EventArgs e)
        {
            btnCreateIndex.Enabled = !( String.IsNullOrEmpty(txtCollectionFile.Text) || String.IsNullOrEmpty(txtIndexFile.Text));
        }

        private void TxtIndexFile_TextChanged(object sender, EventArgs e)
        {
            btnCreateIndex.Enabled = !(String.IsNullOrEmpty(txtCollectionFile.Text) || String.IsNullOrEmpty(txtIndexFile.Text));
        }

        private void BtnCreateIndex_Click(object sender, EventArgs e)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();
            entries = jsonParser.ReadJSON(txtCollectionFile.Text);
            myLuceneApp.IndexCollection(txtIndexFile.Text + @"\Index", entries);
            stopwatch.Stop();

            Time.Text = stopwatch.Elapsed.TotalSeconds.ToString();
        }

        private void SearchContent_TextChanged(object sender, EventArgs e)
        {


        }

        private void Button1_Click(object sender, EventArgs e)
        {
            List<string> pass_id = new List<string>();
            List<string> retrieval_test = new List<string>();
            List<string> retrieval_url = new List<string>();
            int list_length = 0;
            int url_length = 0;
            int id_length = 0;
            string searchword = SearchContent.Text;
            if (Processing_choice.Checked == true)
            {
                Stopwatch stopwatch = Stopwatch.StartNew();
                string string_list = string.Join(" ", textAnalyser.OutputStems(textAnalyser.StopWordFilter(textAnalyser.OutputTokens(searchword))));

                Final_Query.Text = string_list;
                myLuceneApp.CreateSearcher();
                myLuceneApp.CreateParser();
                myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(string_list));
                List<string> retrieval_data = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(searchword));
                list_length = retrieval_data.Count;
                url_length = list_length / 3;
                Number_result.Text = url_length.ToString();
                id_length = list_length -url_length;

                myLuceneApp.CleanUpSearch();
                stopwatch.Stop();
                Searching_time.Text = stopwatch.Elapsed.TotalSeconds.ToString();
                for (int i = 0; i < url_length; i++)
                {
                    retrieval_url.Add(retrieval_data[i]);
                }
                for (int i = url_length; i < id_length; i++)
                {
                    pass_id.Add(retrieval_data[i]);
                }
                for (int i = id_length; i < list_length; i++)
                {
                    retrieval_test.Add((retrieval_data[i]));
                }



            }

            else if(Without_Process.Checked == true)
            {
                Stopwatch stopwatch = Stopwatch.StartNew();
                Final_Query.Text = searchword;

                myLuceneApp.CreateSearcher();
                myLuceneApp.CreateParser();
                myLuceneApp.CleanUpSearch();

                myLuceneApp.CreateSearcher();
                myLuceneApp.CreateParser();
                myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(searchword));
                List<string> retrieval_data = myLuceneApp.DisplayResults(myLuceneApp.SearchIndex(searchword));
                list_length = retrieval_data.Count;
                url_length = list_length / 3;
                Number_result.Text = url_length.ToString();
                id_length = list_length - url_length;

                myLuceneApp.CleanUpSearch();
                stopwatch.Stop();
                Searching_time.Text = stopwatch.Elapsed.TotalSeconds.ToString();

                for (int i = 0; i < url_length; i++)
                {
                    retrieval_url.Add(retrieval_data[i]);
                }
                for (int i = url_length; i < id_length; i++)
                {
                    pass_id.Add(retrieval_data[i]);
                }
                for (int i = id_length; i < list_length; i++)
                {
                    retrieval_test.Add((retrieval_data[i]));
                }

            }
            urlBox1.Text = retrieval_url[0];

            urlBox2.Text = retrieval_url[1];
            urlBox3.Text = retrieval_url[2];
            urlBox4.Text = retrieval_url[3];
            urlBox5.Text = retrieval_url[4];
            urlBox6.Text = retrieval_url[5];
            Urlbox7.Text = retrieval_url[6];
            urlBox8.Text= retrieval_url[7];
            urlBox9.Text= retrieval_url[8];
            urlBox10.Text= retrieval_url[9];
            passage1.Text = retrieval_test[0];
            passage2.Text = retrieval_test[1];
            passage3.Text = retrieval_test[2];
            passage4.Text = retrieval_test[3];
            passage5.Text = retrieval_test[4];
            passage6.Text = retrieval_test[5];
            passage7.Text = retrieval_test[6];
            passage8.Text = retrieval_test[7];
            passage9.Text = retrieval_test[8];
            passage10.Text = retrieval_test[9];

        }

        private void Time_Click(object sender, EventArgs e)
        {
            
        }

        private void Processing_choice_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void Without_Process_CheckedChanged(object sender, EventArgs e)
        {
  
        }

        private void Searching_time_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void Final_Query_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Number_result_Click(object sender, EventArgs e)
        {
            
        }

        private void UrlBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Urlbox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void UrlBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Passage2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage6_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage8_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage9_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passage10_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
