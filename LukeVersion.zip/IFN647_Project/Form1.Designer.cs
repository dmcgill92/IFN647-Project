﻿namespace IFN647_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtCollectionFile = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.lblCollectionFile = new System.Windows.Forms.Label();
            this.txtIndexFile = new System.Windows.Forms.TextBox();
            this.btnBrowse2 = new System.Windows.Forms.Button();
            this.lblIndexSave = new System.Windows.Forms.Label();
            this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.btnCreateIndex = new System.Windows.Forms.Button();
            this.SearchContent = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Time = new System.Windows.Forms.Label();
            this.Without_Process = new System.Windows.Forms.RadioButton();
            this.Processing_choice = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Searching_time = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Final_Query = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Number_result = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.Urlbox7 = new System.Windows.Forms.TextBox();
            this.urlBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.urlBox1 = new System.Windows.Forms.TextBox();
            this.urlBox3 = new System.Windows.Forms.TextBox();
            this.urlBox4 = new System.Windows.Forms.TextBox();
            this.urlBox5 = new System.Windows.Forms.TextBox();
            this.urlBox6 = new System.Windows.Forms.TextBox();
            this.urlBox8 = new System.Windows.Forms.TextBox();
            this.urlBox9 = new System.Windows.Forms.TextBox();
            this.urlBox10 = new System.Windows.Forms.TextBox();
            this.passage1 = new System.Windows.Forms.TextBox();
            this.passage3 = new System.Windows.Forms.TextBox();
            this.passage4 = new System.Windows.Forms.TextBox();
            this.passage5 = new System.Windows.Forms.TextBox();
            this.passage7 = new System.Windows.Forms.TextBox();
            this.passage8 = new System.Windows.Forms.TextBox();
            this.passage10 = new System.Windows.Forms.TextBox();
            this.passage2 = new System.Windows.Forms.TextBox();
            this.passage6 = new System.Windows.Forms.TextBox();
            this.passage9 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCollectionFile
            // 
            this.txtCollectionFile.Location = new System.Drawing.Point(2, 150);
            this.txtCollectionFile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCollectionFile.Name = "txtCollectionFile";
            this.txtCollectionFile.ReadOnly = true;
            this.txtCollectionFile.Size = new System.Drawing.Size(320, 25);
            this.txtCollectionFile.TabIndex = 0;
            this.txtCollectionFile.TextChanged += new System.EventHandler(this.TxtCollectionFile_TextChanged);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(88, 181);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(100, 27);
            this.btnBrowse.TabIndex = 1;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.BtnBrowse_Click);
            // 
            // lblCollectionFile
            // 
            this.lblCollectionFile.AutoSize = true;
            this.lblCollectionFile.Location = new System.Drawing.Point(70, 132);
            this.lblCollectionFile.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCollectionFile.Name = "lblCollectionFile";
            this.lblCollectionFile.Size = new System.Drawing.Size(159, 15);
            this.lblCollectionFile.TabIndex = 2;
            this.lblCollectionFile.Text = "Collection Location";
            // 
            // txtIndexFile
            // 
            this.txtIndexFile.Location = new System.Drawing.Point(3, 328);
            this.txtIndexFile.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtIndexFile.Name = "txtIndexFile";
            this.txtIndexFile.ReadOnly = true;
            this.txtIndexFile.Size = new System.Drawing.Size(320, 25);
            this.txtIndexFile.TabIndex = 0;
            this.txtIndexFile.TextChanged += new System.EventHandler(this.TxtIndexFile_TextChanged);
            // 
            // btnBrowse2
            // 
            this.btnBrowse2.Location = new System.Drawing.Point(89, 359);
            this.btnBrowse2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnBrowse2.Name = "btnBrowse2";
            this.btnBrowse2.Size = new System.Drawing.Size(100, 27);
            this.btnBrowse2.TabIndex = 1;
            this.btnBrowse2.Text = "Browse";
            this.btnBrowse2.UseVisualStyleBackColor = true;
            this.btnBrowse2.Click += new System.EventHandler(this.BtnBrowse2_Click);
            // 
            // lblIndexSave
            // 
            this.lblIndexSave.AutoSize = true;
            this.lblIndexSave.Location = new System.Drawing.Point(71, 310);
            this.lblIndexSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIndexSave.Name = "lblIndexSave";
            this.lblIndexSave.Size = new System.Drawing.Size(159, 15);
            this.lblIndexSave.TabIndex = 2;
            this.lblIndexSave.Text = "Index Save Location";
            // 
            // btnCreateIndex
            // 
            this.btnCreateIndex.Enabled = false;
            this.btnCreateIndex.Location = new System.Drawing.Point(89, 416);
            this.btnCreateIndex.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCreateIndex.Name = "btnCreateIndex";
            this.btnCreateIndex.Size = new System.Drawing.Size(100, 27);
            this.btnCreateIndex.TabIndex = 1;
            this.btnCreateIndex.Text = "Create Index";
            this.btnCreateIndex.UseVisualStyleBackColor = true;
            this.btnCreateIndex.Click += new System.EventHandler(this.BtnCreateIndex_Click);
            // 
            // SearchContent
            // 
            this.SearchContent.Location = new System.Drawing.Point(3, 541);
            this.SearchContent.Name = "SearchContent";
            this.SearchContent.Size = new System.Drawing.Size(320, 25);
            this.SearchContent.TabIndex = 3;
            this.SearchContent.TextChanged += new System.EventHandler(this.SearchContent_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 521);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Input Search Content";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(89, 628);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Search";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Location = new System.Drawing.Point(662, 20);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(15, 15);
            this.Time.TabIndex = 6;
            this.Time.Text = "0";
            this.Time.Click += new System.EventHandler(this.Time_Click);
            // 
            // Without_Process
            // 
            this.Without_Process.AutoSize = true;
            this.Without_Process.Location = new System.Drawing.Point(89, 597);
            this.Without_Process.Name = "Without_Process";
            this.Without_Process.Size = new System.Drawing.Size(148, 19);
            this.Without_Process.TabIndex = 7;
            this.Without_Process.TabStop = true;
            this.Without_Process.Text = "Without Process";
            this.Without_Process.UseVisualStyleBackColor = true;
            this.Without_Process.CheckedChanged += new System.EventHandler(this.Without_Process_CheckedChanged);
            // 
            // Processing_choice
            // 
            this.Processing_choice.AutoSize = true;
            this.Processing_choice.Location = new System.Drawing.Point(89, 572);
            this.Processing_choice.Name = "Processing_choice";
            this.Processing_choice.Size = new System.Drawing.Size(108, 19);
            this.Processing_choice.TabIndex = 8;
            this.Processing_choice.TabStop = true;
            this.Processing_choice.Text = "Processing";
            this.Processing_choice.UseVisualStyleBackColor = true;
            this.Processing_choice.CheckedChanged += new System.EventHandler(this.Processing_choice_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(405, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Time for Indexing   ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(813, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Time for Searching   ";
            // 
            // Searching_time
            // 
            this.Searching_time.AutoSize = true;
            this.Searching_time.Location = new System.Drawing.Point(1070, 20);
            this.Searching_time.Name = "Searching_time";
            this.Searching_time.Size = new System.Drawing.Size(15, 15);
            this.Searching_time.TabIndex = 11;
            this.Searching_time.Text = "0";
            this.Searching_time.Click += new System.EventHandler(this.Searching_time_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(813, 61);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "The final query";
            // 
            // Final_Query
            // 
            this.Final_Query.AutoSize = true;
            this.Final_Query.Location = new System.Drawing.Point(1070, 61);
            this.Final_Query.Name = "Final_Query";
            this.Final_Query.Size = new System.Drawing.Size(15, 15);
            this.Final_Query.TabIndex = 13;
            this.Final_Query.Text = "_";
            this.Final_Query.Click += new System.EventHandler(this.Final_Query_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(405, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(215, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Number of relevant results";
            // 
            // Number_result
            // 
            this.Number_result.AutoSize = true;
            this.Number_result.Location = new System.Drawing.Point(662, 61);
            this.Number_result.Name = "Number_result";
            this.Number_result.Size = new System.Drawing.Size(15, 15);
            this.Number_result.TabIndex = 15;
            this.Number_result.Text = "0";
            this.Number_result.Click += new System.EventHandler(this.Number_result_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.Info;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.Urlbox7, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.urlBox2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label6, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.label11, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.label12, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.label13, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.label14, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.label15, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.label16, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.label17, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label18, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.urlBox1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.urlBox3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.urlBox4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.urlBox5, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.urlBox6, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.urlBox8, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.urlBox9, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.urlBox10, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.passage1, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.passage3, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.passage4, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.passage5, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.passage7, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.passage8, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.passage10, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.passage2, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.passage6, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.passage9, 2, 9);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(350, 93);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 11;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.36364F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 63.63636F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 59F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 54F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 58F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 66F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(968, 601);
            this.tableLayoutPanel1.TabIndex = 16;
            // 
            // Urlbox7
            // 
            this.Urlbox7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Urlbox7.Location = new System.Drawing.Point(50, 372);
            this.Urlbox7.Multiline = true;
            this.Urlbox7.Name = "Urlbox7";
            this.Urlbox7.Size = new System.Drawing.Size(385, 45);
            this.Urlbox7.TabIndex = 18;
            this.Urlbox7.TextChanged += new System.EventHandler(this.Urlbox7_TextChanged);
            // 
            // urlBox2
            // 
            this.urlBox2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox2.Location = new System.Drawing.Point(50, 85);
            this.urlBox2.Multiline = true;
            this.urlBox2.Name = "urlBox2";
            this.urlBox2.Size = new System.Drawing.Size(384, 45);
            this.urlBox2.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Rank";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(195, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "URL / Title";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 15);
            this.label8.TabIndex = 9;
            this.label8.Text = "2";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 158);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(15, 15);
            this.label9.TabIndex = 10;
            this.label9.Text = "3";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 217);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 15);
            this.label10.TabIndex = 11;
            this.label10.Text = "4";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 276);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(15, 15);
            this.label11.TabIndex = 12;
            this.label11.Text = "5";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 332);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 15);
            this.label12.TabIndex = 13;
            this.label12.Text = "6";
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(4, 387);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 15);
            this.label13.TabIndex = 14;
            this.label13.Text = "7";
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 443);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 15);
            this.label14.TabIndex = 15;
            this.label14.Text = "8";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(4, 499);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 15);
            this.label15.TabIndex = 16;
            this.label15.Text = "9";
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 559);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(23, 15);
            this.label16.TabIndex = 17;
            this.label16.Text = "10";
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(671, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 15);
            this.label17.TabIndex = 7;
            this.label17.Text = "Passage";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(4, 45);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 15);
            this.label18.TabIndex = 8;
            this.label18.Text = "1";
            // 
            // urlBox1
            // 
            this.urlBox1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox1.Location = new System.Drawing.Point(50, 32);
            this.urlBox1.Multiline = true;
            this.urlBox1.Name = "urlBox1";
            this.urlBox1.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.urlBox1.Size = new System.Drawing.Size(384, 42);
            this.urlBox1.TabIndex = 18;
            this.urlBox1.TextChanged += new System.EventHandler(this.UrlBox1_TextChanged);
            // 
            // urlBox3
            // 
            this.urlBox3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox3.Location = new System.Drawing.Point(50, 143);
            this.urlBox3.Multiline = true;
            this.urlBox3.Name = "urlBox3";
            this.urlBox3.Size = new System.Drawing.Size(384, 45);
            this.urlBox3.TabIndex = 20;
            // 
            // urlBox4
            // 
            this.urlBox4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox4.Location = new System.Drawing.Point(50, 202);
            this.urlBox4.Multiline = true;
            this.urlBox4.Name = "urlBox4";
            this.urlBox4.Size = new System.Drawing.Size(384, 45);
            this.urlBox4.TabIndex = 21;
            // 
            // urlBox5
            // 
            this.urlBox5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox5.Location = new System.Drawing.Point(50, 261);
            this.urlBox5.Multiline = true;
            this.urlBox5.Name = "urlBox5";
            this.urlBox5.Size = new System.Drawing.Size(384, 45);
            this.urlBox5.TabIndex = 22;
            // 
            // urlBox6
            // 
            this.urlBox6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox6.Location = new System.Drawing.Point(50, 317);
            this.urlBox6.Multiline = true;
            this.urlBox6.Name = "urlBox6";
            this.urlBox6.Size = new System.Drawing.Size(384, 45);
            this.urlBox6.TabIndex = 23;
            // 
            // urlBox8
            // 
            this.urlBox8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox8.Location = new System.Drawing.Point(50, 428);
            this.urlBox8.Multiline = true;
            this.urlBox8.Name = "urlBox8";
            this.urlBox8.Size = new System.Drawing.Size(384, 45);
            this.urlBox8.TabIndex = 25;
            // 
            // urlBox9
            // 
            this.urlBox9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox9.Location = new System.Drawing.Point(50, 484);
            this.urlBox9.Multiline = true;
            this.urlBox9.Name = "urlBox9";
            this.urlBox9.Size = new System.Drawing.Size(384, 45);
            this.urlBox9.TabIndex = 26;
            // 
            // urlBox10
            // 
            this.urlBox10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.urlBox10.Location = new System.Drawing.Point(50, 544);
            this.urlBox10.Multiline = true;
            this.urlBox10.Name = "urlBox10";
            this.urlBox10.Size = new System.Drawing.Size(384, 45);
            this.urlBox10.TabIndex = 27;
            this.urlBox10.TextChanged += new System.EventHandler(this.UrlBox10_TextChanged);
            // 
            // passage1
            // 
            this.passage1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage1.Location = new System.Drawing.Point(442, 32);
            this.passage1.Multiline = true;
            this.passage1.Name = "passage1";
            this.passage1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage1.Size = new System.Drawing.Size(517, 42);
            this.passage1.TabIndex = 28;
            this.passage1.TextChanged += new System.EventHandler(this.Passage1_TextChanged);
            // 
            // passage3
            // 
            this.passage3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage3.Location = new System.Drawing.Point(442, 143);
            this.passage3.Multiline = true;
            this.passage3.Name = "passage3";
            this.passage3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage3.Size = new System.Drawing.Size(517, 45);
            this.passage3.TabIndex = 30;
            this.passage3.TextChanged += new System.EventHandler(this.Passage3_TextChanged);
            // 
            // passage4
            // 
            this.passage4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage4.Location = new System.Drawing.Point(442, 202);
            this.passage4.Multiline = true;
            this.passage4.Name = "passage4";
            this.passage4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage4.Size = new System.Drawing.Size(517, 45);
            this.passage4.TabIndex = 31;
            this.passage4.TextChanged += new System.EventHandler(this.Passage4_TextChanged);
            // 
            // passage5
            // 
            this.passage5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage5.Location = new System.Drawing.Point(442, 261);
            this.passage5.Multiline = true;
            this.passage5.Name = "passage5";
            this.passage5.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage5.Size = new System.Drawing.Size(517, 45);
            this.passage5.TabIndex = 32;
            this.passage5.TextChanged += new System.EventHandler(this.Passage5_TextChanged);
            // 
            // passage7
            // 
            this.passage7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage7.Location = new System.Drawing.Point(442, 372);
            this.passage7.Multiline = true;
            this.passage7.Name = "passage7";
            this.passage7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage7.Size = new System.Drawing.Size(517, 45);
            this.passage7.TabIndex = 34;
            this.passage7.TextChanged += new System.EventHandler(this.Passage7_TextChanged);
            // 
            // passage8
            // 
            this.passage8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage8.Location = new System.Drawing.Point(442, 428);
            this.passage8.Multiline = true;
            this.passage8.Name = "passage8";
            this.passage8.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage8.Size = new System.Drawing.Size(517, 45);
            this.passage8.TabIndex = 35;
            this.passage8.TextChanged += new System.EventHandler(this.Passage8_TextChanged);
            // 
            // passage10
            // 
            this.passage10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage10.Location = new System.Drawing.Point(442, 544);
            this.passage10.Multiline = true;
            this.passage10.Name = "passage10";
            this.passage10.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage10.Size = new System.Drawing.Size(517, 44);
            this.passage10.TabIndex = 37;
            this.passage10.TextChanged += new System.EventHandler(this.Passage10_TextChanged);
            // 
            // passage2
            // 
            this.passage2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage2.Location = new System.Drawing.Point(442, 85);
            this.passage2.Multiline = true;
            this.passage2.Name = "passage2";
            this.passage2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage2.Size = new System.Drawing.Size(517, 45);
            this.passage2.TabIndex = 29;
            this.passage2.TextChanged += new System.EventHandler(this.Passage2_TextChanged);
            // 
            // passage6
            // 
            this.passage6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage6.Location = new System.Drawing.Point(442, 317);
            this.passage6.Multiline = true;
            this.passage6.Name = "passage6";
            this.passage6.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage6.Size = new System.Drawing.Size(517, 45);
            this.passage6.TabIndex = 33;
            this.passage6.TextChanged += new System.EventHandler(this.Passage6_TextChanged);
            // 
            // passage9
            // 
            this.passage9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passage9.Location = new System.Drawing.Point(442, 484);
            this.passage9.Multiline = true;
            this.passage9.Name = "passage9";
            this.passage9.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.passage9.Size = new System.Drawing.Size(517, 45);
            this.passage9.TabIndex = 36;
            this.passage9.TextChanged += new System.EventHandler(this.Passage9_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1224, 700);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(85, 42);
            this.button2.TabIndex = 17;
            this.button2.Text = "save";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1330, 743);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.Number_result);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Final_Query);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Searching_time);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Processing_choice);
            this.Controls.Add(this.Without_Process);
            this.Controls.Add(this.Time);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SearchContent);
            this.Controls.Add(this.lblIndexSave);
            this.Controls.Add(this.lblCollectionFile);
            this.Controls.Add(this.btnCreateIndex);
            this.Controls.Add(this.btnBrowse2);
            this.Controls.Add(this.txtIndexFile);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtCollectionFile);
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "xxx";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.TextBox txtCollectionFile;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label lblCollectionFile;
        private System.Windows.Forms.TextBox txtIndexFile;
        private System.Windows.Forms.Button btnBrowse2;
        private System.Windows.Forms.Label lblIndexSave;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
        private System.Windows.Forms.Button btnCreateIndex;
        private System.Windows.Forms.TextBox SearchContent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.RadioButton Without_Process;
        private System.Windows.Forms.RadioButton Processing_choice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Searching_time;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Final_Query;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Number_result;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox urlBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox urlBox1;
        private System.Windows.Forms.TextBox urlBox3;
        private System.Windows.Forms.TextBox urlBox4;
        private System.Windows.Forms.TextBox urlBox5;
        private System.Windows.Forms.TextBox urlBox6;
        private System.Windows.Forms.TextBox urlBox8;
        private System.Windows.Forms.TextBox urlBox9;
        private System.Windows.Forms.TextBox urlBox10;
        private System.Windows.Forms.TextBox passage1;
        private System.Windows.Forms.TextBox passage2;
        private System.Windows.Forms.TextBox passage3;
        private System.Windows.Forms.TextBox passage4;
        private System.Windows.Forms.TextBox passage5;
        private System.Windows.Forms.TextBox passage6;
        private System.Windows.Forms.TextBox passage7;
        private System.Windows.Forms.TextBox passage8;
        private System.Windows.Forms.TextBox passage10;
        private System.Windows.Forms.TextBox passage9;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Urlbox7;
    }
}

